CREATE TABLE roles (
  id INT IDENTITY PRIMARY KEY,
  name NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE users (
  id INT IDENTITY PRIMARY KEY,
  username NVARCHAR(100) NOT NULL UNIQUE,
  password NVARCHAR(200) NOT NULL,
  role_id INT NULL,
  CONSTRAINT fk_users_roles FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE genres (
  id INT IDENTITY PRIMARY KEY,
  name NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE movies (
  id INT IDENTITY PRIMARY KEY,
  kp_id BIGINT NULL,
  title NVARCHAR(250) NOT NULL,
  description NVARCHAR(MAX),
  year INT,
  rating DECIMAL(3,1)
);

CREATE TABLE movie_genres (
  movie_id INT NOT NULL,
  genre_id INT NOT NULL,
  CONSTRAINT pk_movie_genres PRIMARY KEY (movie_id, genre_id),
  CONSTRAINT fk_mg_movie FOREIGN KEY (movie_id) REFERENCES movies(id),
  CONSTRAINT fk_mg_genre FOREIGN KEY (genre_id) REFERENCES genres(id)
);

CREATE TABLE reviews (
  id INT IDENTITY PRIMARY KEY,
  movie_id INT NOT NULL,
  author NVARCHAR(200),
  content NVARCHAR(MAX),
  created_at DATETIME DEFAULT GETDATE(),
  CONSTRAINT fk_reviews_movie FOREIGN KEY (movie_id) REFERENCES movies(id)
);