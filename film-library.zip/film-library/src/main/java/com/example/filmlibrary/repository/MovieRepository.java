package com.example.filmlibrary.repository;

import com.example.filmlibrary.model.Movie;
import com.example.filmlibrary.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface MovieRepository extends JpaRepository<Movie, Integer> {
    Optional<Movie> findByKpId(Long kpId);
    Page<Movie> findByTitleContainingIgnoreCase(String title, Pageable pageable);

    // Новые методы для работы с пользователями
    List<Movie> findByUser(User user);
    Page<Movie> findByUser(User user, Pageable pageable);
    Integer countByUser(User user);

    @Query("SELECT m FROM Movie m WHERE m.user = :user AND " +
            "(LOWER(m.title) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(m.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
            "LOWER(m.comment) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Movie> findByUserAndSearch(@Param("user") User user,
                                    @Param("search") String search,
                                    Pageable pageable);
}