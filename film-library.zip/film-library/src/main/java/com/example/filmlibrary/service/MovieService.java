package com.example.filmlibrary.service;

import com.example.filmlibrary.model.*;
import com.example.filmlibrary.repository.GenreRepository;
import com.example.filmlibrary.repository.MovieRepository;
import com.example.filmlibrary.repository.UserRepository;
import com.example.filmlibrary.web.dto.MovieDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class MovieService {
    private final MovieRepository movieRepository;
    private final UserRepository userRepository;
    private final GenreRepository genreRepository;
    private final KinopoiskClient kinopoiskClient;
    private static final Logger logger = LoggerFactory.getLogger(MovieService.class);

    public MovieService(MovieRepository movieRepository, UserRepository userRepository,
                        GenreRepository genreRepository, KinopoiskClient kinopoiskClient) {
        this.movieRepository = movieRepository;
        this.userRepository = userRepository;
        this.genreRepository = genreRepository;
        this.kinopoiskClient = kinopoiskClient;
    }

    public Page<Movie> findAllPaged(int page, int size, String search) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("title").ascending());
        if (search == null || search.isBlank()) {
            return movieRepository.findAll(pageable);
        } else {
            return movieRepository.findByTitleContainingIgnoreCase(search, pageable);
        }
    }

    public Page<MovieDTO> getUserMovies(String username, int page, int size, String search) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Movie> movies;

        if (search == null || search.isBlank()) {
            movies = movieRepository.findByUser(user, pageable);
        } else {
            movies = movieRepository.findByUserAndSearch(user, search, pageable);
        }

        return movies.map(this::convertToDTO);
    }

    public Optional<Movie> findById(Integer id) {
        return movieRepository.findById(id);
    }

    @Transactional
    public MovieDTO createMovie(MovieDTO movieDTO, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Movie movie = new Movie();
        movie.setTitle(movieDTO.getTitle());
        movie.setDescription(movieDTO.getDescription());
        movie.setYear(movieDTO.getYear());
        movie.setRating(movieDTO.getRating());
        movie.setComment(movieDTO.getComment());
        movie.setPosterUrl(movieDTO.getPosterUrl());
        movie.setUser(user);
        movie.setCreatedAt(LocalDateTime.now());

        // Обработка типа
        if (movieDTO.getType() != null) {
            try {
                movie.setType(Movie.MovieType.valueOf(movieDTO.getType().toUpperCase()));
            } catch (IllegalArgumentException e) {
                movie.setType(Movie.MovieType.FILM);
            }
        }

        // Обработка жанров
        if (movieDTO.getGenres() != null && !movieDTO.getGenres().isEmpty()) {
            Set<Genre> genres = new HashSet<>();
            for (String genreName : movieDTO.getGenres()) {
                Genre genre = genreRepository.findByName(genreName)
                        .orElseGet(() -> genreRepository.save(new Genre(genreName)));
                genres.add(genre);
            }
            movie.setGenres(genres);
        }

        Movie savedMovie = movieRepository.save(movie);
        return convertToDTO(savedMovie);
    }

    @Transactional
    public MovieDTO importFromKinopoisk(Long kpId, String username) {
        logger.info("Import movie with kpId={} for user={}", kpId, username);

        // Проверяем, не импортирован ли уже этот фильм пользователем
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Optional<Movie> existing = movieRepository.findByKpId(kpId)
                .filter(m -> m.getUser().getId().equals(user.getId()));

        if (existing.isPresent()) {
            logger.info("Movie already imported by user: {}", kpId);
            return convertToDTO(existing.get());
        }

        // Загружаем с Kinopoisk
        Movie fetched = kinopoiskClient.fetchMovieByKpId(kpId);
        if (fetched == null) {
            throw new RuntimeException("Kinopoisk returned empty for id " + kpId);
        }

        // Привязываем к пользователю
        fetched.setUser(user);
        fetched.setKpId(kpId);

        // Сохраняем жанры
        Set<Genre> persistedGenres = new HashSet<>();
        if (fetched.getGenres() != null) {
            persistedGenres = fetched.getGenres().stream().map(g -> {
                return genreRepository.findByName(g.getName())
                        .orElseGet(() -> genreRepository.save(g));
            }).collect(Collectors.toSet());
        }
        fetched.setGenres(persistedGenres);

        Movie savedMovie = movieRepository.save(fetched);
        return convertToDTO(savedMovie);
    }

    @Transactional
    public void deleteMovie(Integer id, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Movie not found"));

        // Проверяем, что фильм принадлежит пользователю
        if (!movie.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("You can only delete your own movies");
        }

        movieRepository.delete(movie);
    }

    private MovieDTO convertToDTO(Movie movie) {
        MovieDTO dto = new MovieDTO();
        dto.setId(movie.getId());
        dto.setTitle(movie.getTitle());
        dto.setDescription(movie.getDescription());
        dto.setYear(movie.getYear());
        dto.setRating(movie.getRating());
        dto.setComment(movie.getComment());
        dto.setPosterUrl(movie.getPosterUrl());
        dto.setType(movie.getType().name());
        dto.setCreatedAt(movie.getCreatedAt());
        dto.setUsername(movie.getUser().getUsername());

        Set<String> genreNames = movie.getGenres().stream()
                .map(Genre::getName)
                .collect(Collectors.toSet());
        dto.setGenres(genreNames);

        return dto;
    }
}