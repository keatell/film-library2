package com.example.filmlibrary.web.dto;

import java.time.LocalDateTime;

public class UserProfileDTO {
    private String username;
    private String email;
    private Integer movieCount;
    private Integer watchlistCount;
    private Double averageRating;
    private LocalDateTime joinedDate;

    public UserProfileDTO() {}

    public UserProfileDTO(String username, String email, Integer movieCount,
                          Integer watchlistCount, Double averageRating, LocalDateTime joinedDate) {
        this.username = username;
        this.email = email;
        this.movieCount = movieCount;
        this.watchlistCount = watchlistCount;
        this.averageRating = averageRating;
        this.joinedDate = joinedDate;
    }

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getMovieCount() { return movieCount; }
    public void setMovieCount(Integer movieCount) { this.movieCount = movieCount; }

    public Integer getWatchlistCount() { return watchlistCount; }
    public void setWatchlistCount(Integer watchlistCount) { this.watchlistCount = watchlistCount; }

    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }

    public LocalDateTime getJoinedDate() { return joinedDate; }
    public void setJoinedDate(LocalDateTime joinedDate) { this.joinedDate = joinedDate; }
}