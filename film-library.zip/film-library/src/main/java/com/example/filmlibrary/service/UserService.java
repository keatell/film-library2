package com.example.filmlibrary.service;

import com.example.filmlibrary.model.User;
import com.example.filmlibrary.repository.MovieRepository;
import com.example.filmlibrary.repository.UserRepository;
import com.example.filmlibrary.web.dto.UserProfileDTO;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final MovieRepository movieRepository;

    public UserService(UserRepository userRepository, MovieRepository movieRepository) {
        this.userRepository = userRepository;
        this.movieRepository = movieRepository;
    }

    public UserProfileDTO getUserProfile(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Подсчитываем количество фильмов пользователя
        Integer movieCount = movieRepository.countByUser(user);

        // TODO: Добавить подсчёт watchlist, когда будет реализовано
        Integer watchlistCount = 0;

        // TODO: Вычислять средний рейтинг
        Double averageRating = 0.0;

        return new UserProfileDTO(
                user.getUsername(),
                user.getEmail(),
                movieCount,
                watchlistCount,
                averageRating,
                user.getCreatedAt()
        );
    }
}