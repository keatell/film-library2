package com.example.filmlibrary.web;

import com.example.filmlibrary.web.dto.AuthRequest;
import com.example.filmlibrary.web.dto.AuthResponse;
import com.example.filmlibrary.model.User;
import com.example.filmlibrary.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) { this.authService = authService; }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest req) {
        authService.register(req.username(), req.password());
        return ResponseEntity.ok("Registered");
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest req) {
        String token = authService.login(req.username(), req.password());
        return ResponseEntity.ok(new AuthResponse(token));
    }
}