package com.example.filmlibrary.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")  // ✅ Добавляем маппинг для корневого пути
public class TestController {

    @GetMapping("/")
    public ResponseEntity<String> home() {
        String html = """
            <html>
            <head>
                <title>Film Library API</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; }
                    h1 { color: #333; }
                    ul { list-style-type: none; padding: 0; }
                    li { margin: 10px 0; }
                    a { color: #0066cc; text-decoration: none; }
                    a:hover { text-decoration: underline; }
                    .container { max-width: 800px; margin: 0 auto; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🎬 Film Library Backend is running!</h1>
                    <p>API endpoints:</p>
                    <ul>
                        <li>📝 <strong>POST</strong> /api/auth/register - Register new user</li>
                        <li>🔑 <strong>POST</strong> /api/auth/login - Login</li>
                        <li>🎥 <strong>GET</strong> /api/movies - Get all movies</li>
                        <li>➕ <strong>POST</strong> /api/movies/import?kpId=301 - Import movie from Kinopoisk</li>
                        <li>❤️ <strong>GET</strong> /health - Health check</li>
                        <li>🧪 <strong>GET</strong> /api/test - Test endpoint</li>
                    </ul>
                    
                    <h3>Test users:</h3>
                    <ul>
                        <li>Username: <strong>Y</strong></li>
                        <li>Password: <strong>CineDairy123!</strong></li>
                    </ul>
                </div>
            </body>
            </html>
            """;
        return ResponseEntity.ok().header("Content-Type", "text/html").body(html);
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        String json = String.format(
                "{\"status\": \"OK\", \"service\": \"film-library-api\", \"timestamp\": %d}",
                System.currentTimeMillis()
        );
        return ResponseEntity.ok().header("Content-Type", "application/json").body(json);
    }

    @GetMapping("/api/test")
    public ResponseEntity<String> test() {
        String json = String.format(
                "{\"message\": \"Test endpoint works!\", \"timestamp\": %d}",
                System.currentTimeMillis()
        );
        return ResponseEntity.ok().header("Content-Type", "application/json").body(json);
    }

    // Добавляем обработчик OPTIONS для CORS
    @RequestMapping(value = "/**", method = RequestMethod.OPTIONS)
    public ResponseEntity<Void> options() {
        return ResponseEntity.ok().build();
    }
}