package com.example.filmlibrary.controller;

import com.example.filmlibrary.model.Movie;
import com.example.filmlibrary.service.MovieService;
import com.example.filmlibrary.web.dto.MovieDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/movies")
public class MovieController {
    private final MovieService movieService;
    private static final Logger logger = LoggerFactory.getLogger(MovieController.class);

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping
    public ResponseEntity<Page<Movie>> allPaged(@RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "10") int size,
                                                @RequestParam(required = false) String search) {
        return ResponseEntity.ok(movieService.findAllPaged(page, size, search));
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Page<MovieDTO>> getUserMovies(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String search) {

        String username = userDetails.getUsername();
        Page<MovieDTO> movies = movieService.getUserMovies(username, page, size, search);
        return ResponseEntity.ok(movies);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Movie> getOne(@PathVariable Integer id) {
        return movieService.findById(id).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<MovieDTO> createMovie(@AuthenticationPrincipal UserDetails userDetails,
                                                @RequestBody MovieDTO movieDTO) {
        String username = userDetails.getUsername();
        MovieDTO createdMovie = movieService.createMovie(movieDTO, username);
        return ResponseEntity.ok(createdMovie);
    }

    @PostMapping("/import")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<MovieDTO> importByKpId(@AuthenticationPrincipal UserDetails userDetails,
                                                 @RequestParam("kpId") Long kpId) {
        logger.info("Import request for kpId={} by user={}", kpId, userDetails.getUsername());
        String username = userDetails.getUsername();
        MovieDTO movie = movieService.importFromKinopoisk(kpId, username);
        return ResponseEntity.ok(movie);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> deleteMovie(@AuthenticationPrincipal UserDetails userDetails,
                                            @PathVariable Integer id) {
        String username = userDetails.getUsername();
        movieService.deleteMovie(id, username);
        return ResponseEntity.noContent().build();
    }
}