package com.example.filmlibrary.service;

import com.example.filmlibrary.model.Genre;
import com.example.filmlibrary.model.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Гибкий Kinopoisk client — пытается корректно вытянуть поля из разного JSON-формата.
 * Использует заголовок X-API-KEY. Базовый URL в application.yml.
 */
@Component
public class KinopoiskClient {
    private final RestTemplate restTemplate = new RestTemplate();
    private final String baseUrl;
    private final String apiKey;
    private static final Logger logger = LoggerFactory.getLogger(KinopoiskClient.class);

    public KinopoiskClient(@Value("${kinopoisk.api.url}") String baseUrl,
                           @Value("${kinopoisk.api.key}") String apiKey) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
    }

    @SuppressWarnings("unchecked")
    public Movie fetchMovieByKpId(Long kpId) {
        // Попробуем несколько распространённых путей; основной — /v1/movie/{id} или /v1.3/movie/{id} или /movie/{id}
        List<String> candidates = List.of(
                baseUrl + "/v1/movie/" + kpId,
                baseUrl + "/v1.3/movie/" + kpId,
                baseUrl + "/movie/" + kpId,
                baseUrl + "/movies/" + kpId,
                baseUrl + "/v1/film/" + kpId
        );

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-API-KEY", apiKey);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        Map<String, Object> body = null;
        for (String url : candidates) {
            try {
                logger.info("Trying Kinopoisk URL: {}", url);
                ResponseEntity<Map> resp = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
                if (resp.getStatusCode() == HttpStatus.OK && resp.getBody() != null) {
                    body = resp.getBody();
                    break;
                }
            } catch (Exception ex) {
                logger.debug("Request to {} failed: {}", url, ex.getMessage());
            }
        }

        if (body == null) {
            logger.warn("Kinopoisk: no response for kpId={}", kpId);
            return null;
        }

        // Извлекаем поля гибко
        Movie movie = new Movie();
        movie.setKpId(kpId);

        // title: try multiple keys
        String title = pickFirstString(body, "title", "name", "ruName", "localizedName");
        movie.setTitle(title != null ? title : "Unknown title");

        // description
        String description = pickFirstString(body, "description", "synopsis", "shortDescription", "overview");
        movie.setDescription(description);

        // year: try 'year' or 'productionYear'
        Double rating = pickFirstDouble(body, "rating", "ratingKinopoisk", "kpRating", "rating.imdb");
        movie.setRating(rating);

        Integer year = pickFirstInt(body, "year", "productionYear", "releaseYear");
        movie.setYear(year);

        // genres: can be list of strings or list of objects
        Set<Genre> genres = new HashSet<>();
        Object genresObj = body.get("genres");
        if (genresObj instanceof Collection) {
            for (Object g : (Collection<?>) genresObj) {
                if (g instanceof String) {
                    genres.add(new Genre((String) g));
                } else if (g instanceof Map) {
                    Object name = ((Map<?, ?>) g).get("name");
                    if (name == null) name = ((Map<?, ?>) g).get("genre");
                    if (name instanceof String) genres.add(new Genre((String) name));
                }
            }
        } else {
            // maybe field genre is comma separated string
            Object g = body.get("genre");
            if (g instanceof String) {
                String[] parts = ((String) g).split(",\\s*");
                for (String s : parts) genres.add(new Genre(s.trim()));
            }
        }
        movie.setGenres(genres);
        return movie;
    }

    private String pickFirstString(Map<String, Object> m, String... keys) {
        for (String k : keys) {
            Object v = deepGet(m, k);
            if (v instanceof String) return (String) v;
        }
        return null;
    }

    private Integer pickFirstInt(Map<String, Object> m, String... keys) {
        for (String k : keys) {
            Object v = deepGet(m, k);
            if (v instanceof Number) return ((Number) v).intValue();
            if (v instanceof String) {
                try { return Integer.parseInt((String) v); } catch (Exception ignored) {}
            }
        }
        return null;
    }

    private Double pickFirstDouble(Map<String, Object> m, String... keys) {
        for (String k : keys) {
            Object v = deepGet(m, k);
            if (v instanceof Number) return ((Number) v).doubleValue();
            if (v instanceof String) {
                try { return Double.parseDouble((String) v); } catch (Exception ignored) {}
            }
        }
        return null;
    }

    // supports simple deep keys like "rating.imdb"
    private Object deepGet(Map<String, Object> m, String key) {
        if (!key.contains(".")) {
            return m.get(key);
        }
        String[] parts = key.split("\\.");
        Object cur = m;
        for (String p : parts) {
            if (!(cur instanceof Map)) return null;
            cur = ((Map<?, ?>) cur).get(p);
            if (cur == null) return null;
        }
        return cur;
    }
}