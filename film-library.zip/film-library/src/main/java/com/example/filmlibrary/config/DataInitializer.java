package com.example.filmlibrary.config;

import com.example.filmlibrary.model.Role;
import com.example.filmlibrary.model.User;
import com.example.filmlibrary.repository.RoleRepository;
import com.example.filmlibrary.repository.UserRepository;
import org.slf4j.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(RoleRepository roleRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        Role userRole = roleRepository.findByName("ROLE_USER").orElseGet(() -> roleRepository.save(new Role("ROLE_USER")));
        // Seed user Y / CineDairy123!
        if (userRepository.findByUsername("Y").isEmpty()) {
            User u = new User();
            u.setUsername("Y");
            u.setPassword(passwordEncoder.encode("CineDairy123!"));
            u.setRole(userRole);
            userRepository.save(u);
            logger.info("Seeded user 'Y'");
        } else {
            logger.info("User 'Y' already exists");
        }
    }
}