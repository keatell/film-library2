package com.example.filmlibrary.web.dto;

public record AuthRequest(String username, String password) {}