package com.example.filmlibrary.repository;

import com.example.filmlibrary.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
}