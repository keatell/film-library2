package com.example.filmlibrary.service;

import com.example.filmlibrary.model.Genre;
import com.example.filmlibrary.model.Movie;
import com.example.filmlibrary.repository.GenreRepository;
import com.example.filmlibrary.repository.MovieRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

public class MovieServiceTest {

    private MovieRepository movieRepository;
    private GenreRepository genreRepository;
    private KinopoiskClient kinopoiskClient;
    private MovieService movieService;

    @BeforeEach
    void setup() {
        movieRepository = Mockito.mock(MovieRepository.class);
        genreRepository = Mockito.mock(GenreRepository.class);
        kinopoiskClient = Mockito.mock(KinopoiskClient.class);
        movieService = new MovieService(movieRepository, genreRepository, kinopoiskClient);
    }

    @Test
    void importFromKinopoisk_savesMovieWhenNotExists() {
        Long kpId = 12345L;
        Mockito.when(movieRepository.findByKpId(kpId)).thenReturn(Optional.empty());

        Movie fetched = new Movie();
        fetched.setKpId(kpId);
        fetched.setTitle("Test Movie");
        Genre g = new Genre();
        g.setName("Drama");
        fetched.setGenres(Set.of(g));

        Mockito.when(kinopoiskClient.fetchMovieByKpId(kpId)).thenReturn(fetched);
        Mockito.when(genreRepository.findByName("Drama")).thenReturn(Optional.of(g));
        Mockito.when(movieRepository.save(any(Movie.class))).thenAnswer(inv -> inv.getArgument(0));

        Movie saved = movieService.importFromKinopoisk(kpId);

        assertNotNull(saved);
        assertEquals("Test Movie", saved.getTitle());
        Mockito.verify(movieRepository).save(any(Movie.class));
    }
}