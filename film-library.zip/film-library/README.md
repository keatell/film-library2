```markdown
# FilmLibrary

Полнофункциональный шаблон "фильмотека" (Spring Boot + JWT + MSSQL + React + Docker)

Ключевые особенности:
- Backend: Java 17, Spring Boot 3, Spring Data JPA, Spring Security + JWT
- Frontend: React (create-react-app), адаптивная верстка
- DB: Microsoft SQL Server (через Docker)
- Kinopoisk: внешнее API, используется X-API-KEY (ключ: c68c1a6c-4e9c-4b9e-a18d-c28c461bd627)
- Seed user: username = `Y`, password = `CineDairy123!` (ROLE_USER)
- Docker: docker-compose запускает mssql, backend, frontend
- Unit tests: пример для MovieService

Запуск через Docker (рекомендуется):
1. Клонируйте/распакуйте проект в папку `film-library`.
2. (Опционально) Отредактируйте `src/main/resources/application.yml` если хотите поменять секреты/пароли.
3. Запустите:
   docker-compose up --build

Приложение:
- Backend: http://localhost:8080
- Frontend: http://localhost:3000

API:
- POST /api/auth/register { "username","password" }
- POST /api/auth/login { "username","password" } => { "token": "..." }
- GET  /api/movies?page=0&size=10&search=...
- GET  /api/movies/{id}
- POST /api/movies/import?kpId={kpId}  (требует Authorization: Bearer <token>)

Kinopoisk:
- В application.yml установлен ключ: c68c1a6c-4e9c-4b9e-a18d-c28c461bd627
- Базовый URL по умолчанию: https://api.kinopoisk.dev (если у вас иной — поменяйте в application.yml)
- KinopoiskClient реализован гибко и пытается корректно извлечь поля из разных форматов JSON-ответов.

Как собрать zip (локально):
- В корне проекта выполните (Linux/macOS):
  zip -r film-library.zip .

- В Windows (PowerShell):
  Compress-Archive -Path * -DestinationPath film-library.zip

Данные по умолчанию для MSSQL/Docker:
- SA password: `YourStrong!Passw0rd` (в docker-compose.yml)
- DB name: filmlib

Что можно сделать далее:
- Добавить ROLE_ADMIN и разграничить права (сейчас все зареганные пользователи могут импортировать)
- Подключить конкретный Kinopoisk-эндпоинт (если потребуется детальная адаптация)
- CI/CD, deploy, HTTPS и т.д.

```