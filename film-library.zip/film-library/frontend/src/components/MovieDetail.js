import React from 'react';

export default function MovieDetail({ movie, onBack }) {
  if (!movie) return <div>No movie</div>;
  return (
    <div>
      <button onClick={onBack} className="btn btn-outline">Back</button>
      <div className="movie-card" style={{marginTop:12}}>
        <img src={movie.poster || `https://via.placeholder.com/600x400/1a1a2e/6a11cb?text=No+Image`} className="movie-poster" alt={movie.title} />
        <div className="movie-info">
          <h2 className="movie-title">{movie.title} {movie.year ? `(${movie.year})` : ''}</h2>
          <div style={{fontSize:14, color:'#9fb0c9'}}>{movie.description}</div>
          <div style={{marginTop:8}}>Rating: {movie.rating || 'N/A'}</div>
          <div style={{marginTop:8}}>Genres: {movie.genres ? (Array.isArray(movie.genres) ? movie.genres.join(', ') : movie.genre) : (movie.genre||'-')}</div>
        </div>
      </div>
    </div>
  );
}