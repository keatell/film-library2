import React from 'react';

export default function Navbar({ current, onNavigate }) {
  const links = [
    { id: 'home', label: 'Главная' },
    { id: 'movies', label: 'Мои фильмы' },
    { id: 'watchlist', label: 'Хочу посмотреть' },
    { id: 'add', label: 'Добавить' },
    { id: 'stats', label: 'Статистика' },
  ];

  return (
    <nav style={{background:'rgba(26,26,46,0.6)',backdropFilter:'blur(6px)'}}>
      <div className="container" style={{display:'flex',justifyContent:'center',padding:'12px 0'}}>
        <ul style={{display:'flex',gap:20,listStyle:'none',margin:0,padding:0}}>
          {links.map(l => (
            <li key={l.id}>
              <a href="#" onClick={e => { e.preventDefault(); onNavigate(l.id); }} className={current === l.id ? 'active' : ''} style={{padding:'8px 12px',borderRadius:20, color: current === l.id ? '#ffd166' : 'inherit'}}>
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}