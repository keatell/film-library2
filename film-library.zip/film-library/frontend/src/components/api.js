import React from 'react';

const API_BASE = 'http://localhost:8080/api';

// Функция для обработки ошибок API
const handleApiError = async (response) => {
    if (!response.ok) {
        let errorMsg = `Ошибка ${response.status}`;
        try {
            const errorData = await response.json();
            errorMsg = errorData.message || errorMsg;
        } catch (e) {
            const text = await response.text();
            if (text) errorMsg = text;
        }
        throw new Error(errorMsg);
    }
    return response;
};

// API для работы с фильмами
export const movieApi = {
    // Получить все фильмы пользователя
    getMyMovies: async (token) => {
        const response = await fetch(`${API_BASE}/movies/my`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        await handleApiError(response);
        const data = await response.json();
        return data.content || data || [];
    },

    // Добавить фильм
    addMovie: async (movie, token) => {
        const response = await fetch(`${API_BASE}/movies`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(movie)
        });
        await handleApiError(response);
        return await response.json();
    },

    // Обновить фильм
    updateMovie: async (id, movie, token) => {
        const response = await fetch(`${API_BASE}/movies/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(movie)
        });
        await handleApiError(response);
        return await response.json();
    },

    // Удалить фильм
    deleteMovie: async (id, token) => {
        const response = await fetch(`${API_BASE}/movies/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        await handleApiError(response);
        return true;
    },

    // Импорт фильма из Kinopoisk
    importFromKinopoisk: async (kpId, token) => {
        const response = await fetch(`${API_BASE}/movies/import?kpId=${kpId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        await handleApiError(response);
        return await response.json();
    }
};

// API для работы со списком ожидания
export const watchlistApi = {
    // Получить список ожидания
    getWatchlist: async (token) => {
        const response = await fetch(`${API_BASE}/watchlist`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        await handleApiError(response);
        const data = await response.json();
        return data.content || data || [];
    },

    // Добавить в список ожидания
    addToWatchlist: async (item, token) => {
        const response = await fetch(`${API_BASE}/watchlist`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(item)
        });
        await handleApiError(response);
        return await response.json();
    },

    // Удалить из списка ожидания
    removeFromWatchlist: async (id, token) => {
        const response = await fetch(`${API_BASE}/watchlist/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        await handleApiError(response);
        return true;
    }
};

// API для работы со статистикой
export const statsApi = {
    // Получить статистику
    getStats: async (token) => {
        const response = await fetch(`${API_BASE}/stats`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        await handleApiError(response);
        return await response.json();
    }
};

// API для работы с пользователем
export const userApi = {
    // Получить профиль пользователя
    getProfile: async (token) => {
        const response = await fetch(`${API_BASE}/user/profile`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        await handleApiError(response);
        return await response.json();
    },

    // Обновить профиль
    updateProfile: async (profile, token) => {
        const response = await fetch(`${API_BASE}/user/profile`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(profile)
        });
        await handleApiError(response);
        return await response.json();
    }
};

// Компонент для отображения состояния загрузки
export const ApiStatus = ({ loading, error, children }) => {
    if (loading) {
        return (
            <div style={{ textAlign: 'center', padding: '20px' }}>
                <div className="spinner" style={{ width: '30px', height: '30px', margin: '0 auto 10px' }}></div>
                <p style={{ color: 'var(--gray)' }}>Загрузка...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div style={{
                background: 'rgba(231, 76, 60, 0.1)',
                padding: '15px',
                borderRadius: '8px',
                margin: '20px 0',
                border: '1px solid rgba(231, 76, 60, 0.3)'
            }}>
                <p style={{ color: '#ff6b6b', margin: 0 }}>
                    <i className="fas fa-exclamation-circle" style={{ marginRight: '8px' }}></i>
                    {error}
                </p>
            </div>
        );
    }

    return children;
};