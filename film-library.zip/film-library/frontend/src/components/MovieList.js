import React, { useState, useMemo } from 'react';
import MovieCard from './MovieCard';

export default function MovieList({ movies, onOpenDetail, onDelete, token }) {
  const [page, setPage] = useState(0);
  const [size] = useState(8);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState({ genre: 'all', type: 'all', rating: 'all', sort: 'newest' });

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    let arr = movies.filter(m => {
      // normalize rating to 5-scale for filtering
      let movieRating = Number(m.rating) || 0;
      if (movieRating > 5) { movieRating = movieRating / 2; } // assume original 10-scale
      movieRating = Math.round(movieRating * 10) / 10;

      if (filter.type !== 'all' && m.type !== filter.type) return false;
      if (filter.genre !== 'all' && (!m.genre || !m.genre.toLowerCase().includes(filter.genre.toLowerCase()))) return false;
      if (filter.rating !== 'all' && (Number(movieRating) < Number(filter.rating))) return false;
      if (s && !m.title.toLowerCase().includes(s) && !(m.genre && m.genre.toLowerCase().includes(s)) && !(m.year && String(m.year).includes(s))) return false;
      return true;
    });
    switch (filter.sort) {
      case 'newest': arr.sort((a,b)=> new Date(b.dateAdded || b.createdAt) - new Date(a.dateAdded || a.createdAt)); break;
      case 'oldest': arr.sort((a,b)=> new Date(a.dateAdded || a.createdAt) - new Date(b.dateAdded || b.createdAt)); break;
      case 'rating': arr.sort((a,b)=> {
        let ra = Number(a.rating)||0; let rb = Number(b.rating)||0;
        if (ra>5) ra = ra/2;
        if (rb>5) rb = rb/2;
        return rb - ra;
      }); break;
      case 'title': arr.sort((a,b)=> a.title.localeCompare(b.title)); break;
      default: break;
    }
    return arr;
  }, [movies, filter, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / size));
  const pageSlice = filtered.slice(page * size, (page+1)*size);

  // Получаем уникальные жанры для фильтра
  const uniqueGenres = useMemo(() => {
    const genres = new Set();
    movies.forEach(m => {
      if (m.genre) {
        if (Array.isArray(m.genre)) {
          m.genre.forEach(g => genres.add(g));
        } else if (typeof m.genre === 'string') {
          m.genre.split(',').forEach(g => genres.add(g.trim()));
        }
      }
    });
    return Array.from(genres).sort();
  }, [movies]);

  return (
      <div>
        <div style={{ marginBottom: '30px' }}>
          <h2 className="page-title" style={{ marginBottom: '20px' }}>Мои фильмы</h2>

          <div className="top-controls" style={{
            display: 'flex',
            gap: '15px',
            marginBottom: '20px',
            alignItems: 'center',
            flexWrap: 'wrap'
          }}>
            <div style={{ flex: 1, minWidth: '250px' }}>
              <div className="search-container">
                <input
                    style={{ width: '100%' }}
                    placeholder="Поиск по названию, жанру или году..."
                    value={search}
                    onChange={e => { setSearch(e.target.value); setPage(0); }}
                />
              </div>
            </div>

            {token && (
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button className="btn" onClick={() => window.location.href = '#add'}>
                    <i className="fas fa-plus"></i> Добавить фильм
                  </button>
                </div>
            )}
          </div>

          <div style={{
            display: 'flex',
            gap: '15px',
            marginBottom: '25px',
            flexWrap: 'wrap',
            padding: '15px',
            background: 'rgba(255, 255, 255, 0.05)',
            borderRadius: '12px',
            border: '1px solid rgba(255, 255, 255, 0.1)'
          }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '180px' }}>
              <label style={{ fontSize: '14px', color: 'var(--accent)', fontWeight: '500' }}>Тип</label>
              <select
                  value={filter.type}
                  onChange={e => setFilter(f => ({...f, type: e.target.value}))}
                  style={{
                    width: '100%',
                    padding: '10px 15px',
                    background: 'rgba(26, 26, 46, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '8px',
                    color: 'var(--light)',
                    fontSize: '14px',
                    cursor: 'pointer'
                  }}
              >
                <option value="all">Все типы</option>
                <option value="FILM">Фильм</option>
                <option value="TV_SERIES">Сериал</option>
                <option value="MINI_SERIES">Мини-сериал</option>
                <option value="TV_SHOW">ТВ-шоу</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '180px' }}>
              <label style={{ fontSize: '14px', color: 'var(--accent)', fontWeight: '500' }}>Жанр</label>
              <select
                  value={filter.genre}
                  onChange={e => setFilter(f => ({...f, genre: e.target.value}))}
                  style={{
                    width: '100%',
                    padding: '10px 15px',
                    background: 'rgba(26, 26, 46, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '8px',
                    color: 'var(--light)',
                    fontSize: '14px',
                    cursor: 'pointer'
                  }}
              >
                <option value="all">Все жанры</option>
                {uniqueGenres.map(genre => (
                    <option key={genre} value={genre}>{genre}</option>
                ))}
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '180px' }}>
              <label style={{ fontSize: '14px', color: 'var(--accent)', fontWeight: '500' }}>Оценка</label>
              <select
                  value={filter.rating}
                  onChange={e => setFilter(f => ({...f, rating: e.target.value}))}
                  style={{
                    width: '100%',
                    padding: '10px 15px',
                    background: 'rgba(26, 26, 46, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '8px',
                    color: 'var(--light)',
                    fontSize: '14px',
                    cursor: 'pointer'
                  }}
              >
                <option value="all">Любая оценка</option>
                <option value="5">5+</option>
                <option value="4">4+</option>
                <option value="3">3+</option>
                <option value="2">2+</option>
                <option value="1">1+</option>
              </select>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '180px' }}>
              <label style={{ fontSize: '14px', color: 'var(--accent)', fontWeight: '500' }}>Сортировка</label>
              <select
                  value={filter.sort}
                  onChange={e => setFilter(f => ({...f, sort: e.target.value}))}
                  style={{
                    width: '100%',
                    padding: '10px 15px',
                    background: 'rgba(26, 26, 46, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '8px',
                    color: 'var(--light)',
                    fontSize: '14px',
                    cursor: 'pointer'
                  }}
              >
                <option value="newest">Сначала новые</option>
                <option value="oldest">Сначала старые</option>
                <option value="rating">По оценке</option>
                <option value="title">По названию</option>
              </select>
            </div>

            <div style={{ display: 'flex', alignItems: 'flex-end' }}>
              <button
                  className="btn btn-outline"
                  onClick={() => {
                    setFilter({ genre: 'all', type: 'all', rating: 'all', sort: 'newest' });
                    setSearch('');
                    setPage(0);
                  }}
                  style={{
                    padding: '10px 20px',
                    height: '42px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}
              >
                <i className="fas fa-redo"></i>
                Сбросить
              </button>
            </div>
          </div>
        </div>

        {filtered.length === 0 ? (
            <div className="empty-state" style={{ marginTop: '40px' }}>
              <i className="fas fa-film"></i>
              <h3>Фильмы не найдены</h3>
              <p>Попробуйте изменить параметры поиска или фильтрации</p>
              <button
                  className="btn btn-outline"
                  onClick={() => {
                    setFilter({ genre: 'all', type: 'all', rating: 'all', sort: 'newest' });
                    setSearch('');
                  }}
                  style={{ marginTop: '15px' }}
              >
                Сбросить фильтры
              </button>
            </div>
        ) : (
            <>
              <div style={{ marginBottom: '20px', color: 'var(--gray)', fontSize: '14px' }}>
                Найдено фильмов: <strong>{filtered.length}</strong>
                {search && (
                    <span style={{ marginLeft: '15px' }}>
                по запросу: "<strong>{search}</strong>"
              </span>
                )}
              </div>

              <div className="movies-grid">
                {pageSlice.map(m => (
                    <MovieCard
                        key={m.id}
                        movie={m}
                        onOpen={() => onOpenDetail(m)}
                        onDelete={token ? (() => onDelete(m.id)) : (() => onDelete(m.id))}
                    />
                ))}
              </div>

              {totalPages > 1 && (
                  <div style={{
                    marginTop: '30px',
                    display: 'flex',
                    gap: '10px',
                    justifyContent: 'center',
                    alignItems: 'center',
                    flexWrap: 'wrap'
                  }}>
                    <button
                        className="btn btn-outline"
                        onClick={() => setPage(p => Math.max(0, p-1))}
                        disabled={page === 0}
                        style={{ padding: '10px 20px' }}
                    >
                      <i className="fas fa-chevron-left"></i> Назад
                    </button>

                    <div style={{
                      display: 'flex',
                      gap: '5px',
                      alignItems: 'center'
                    }}>
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum;
                        if (totalPages <= 5) {
                          pageNum = i;
                        } else if (page <= 2) {
                          pageNum = i;
                        } else if (page >= totalPages - 3) {
                          pageNum = totalPages - 5 + i;
                        } else {
                          pageNum = page - 2 + i;
                        }

                        return (
                            <button
                                key={pageNum}
                                onClick={() => setPage(pageNum)}
                                style={{
                                  padding: '8px 12px',
                                  background: page === pageNum ? 'var(--primary)' : 'rgba(255, 255, 255, 0.1)',
                                  border: '1px solid rgba(255, 255, 255, 0.2)',
                                  borderRadius: '6px',
                                  color: page === pageNum ? 'white' : 'var(--light)',
                                  cursor: 'pointer',
                                  minWidth: '40px',
                                  transition: 'var(--transition)'
                                }}
                            >
                              {pageNum + 1}
                            </button>
                        );
                      })}
                    </div>

                    <div style={{
                      padding: '10px 15px',
                      background: 'rgba(255, 255, 255, 0.05)',
                      borderRadius: '6px',
                      fontSize: '14px',
                      color: 'var(--gray)'
                    }}>
                      Страница {page + 1} из {totalPages}
                    </div>

                    <button
                        className="btn btn-outline"
                        onClick={() => setPage(p => Math.min(totalPages-1, p+1))}
                        disabled={page+1 >= totalPages}
                        style={{ padding: '10px 20px' }}
                    >
                      Вперед <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
              )}
            </>
        )}
      </div>
  );
}