import React from 'react';

export default function MovieCard({ movie, onOpen, onDelete }) {
    const poster = movie.posterUrl || movie.poster || `https://via.placeholder.com/300x400/1a1a2e/6a11cb?text=No+Image`;
    const rawRating = Number(movie.rating);

    // Нормализуем рейтинг к шкале 5
    const displayRating = (isNaN(rawRating) || rawRating === 0) ? 'N/A' :
        (rawRating > 5 ? (rawRating / 2).toFixed(1) : rawRating.toFixed(1));

    const ratingStr = displayRating === 'N/A' ? 'N/A' : `${displayRating}`;

    // Обрабатываем жанры в разных форматах
    const getGenres = () => {
        if (movie.genres) {
            if (Array.isArray(movie.genres)) {
                return movie.genres.map(g => g.name || g.genre || g);
            } else if (typeof movie.genres === 'string') {
                return movie.genres.split(',').map(g => g.trim());
            }
        }
        if (movie.genre) {
            if (Array.isArray(movie.genre)) {
                return movie.genre;
            } else if (typeof movie.genre === 'string') {
                return movie.genre.split(',').map(g => g.trim());
            }
        }
        return [];
    };

    const genres = getGenres();

    return (
        <div className="movie-card" onClick={() => { if (onOpen) onOpen(); }}>
            <img
                src={poster}
                className="movie-poster"
                alt={movie.title}
                onError={(e) => {
                    e.currentTarget.src = 'https://via.placeholder.com/300x400/1a1a2e/6a11cb?text=No+Image';
                }}
            />
            <div className="movie-info">
                <div className="movie-title">
                    {movie.title}
                    {movie.year ? ` (${movie.year})` : ''}
                </div>

                <div className="movie-meta">
          <span className="rating-badge" style={{
              background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))',
              color: 'white',
              padding: '4px 10px',
              borderRadius: '12px',
              fontSize: '14px',
              fontWeight: '600',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              minWidth: '50px',
              justifyContent: 'center'
          }}>
            <i className="fas fa-star" style={{ fontSize: '12px' }}></i>
              {ratingStr}/5
          </span>
                    <span style={{ margin: '0 8px', color: 'var(--gray)' }}>•</span>
                    <span style={{ fontSize: '14px', color: 'var(--gray)' }}>
            {movie.type || 'Фильм'}
          </span>
                </div>

                {genres.length > 0 && (
                    <div className="movie-genres" style={{
                        marginTop: '8px',
                        marginBottom: '12px',
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: '6px'
                    }}>
                        {genres.slice(0, 2).map((genre, idx) => (
                            <span key={idx} style={{
                                background: 'rgba(106, 17, 203, 0.2)',
                                color: 'var(--primary)',
                                padding: '4px 10px',
                                borderRadius: '15px',
                                fontSize: '12px',
                                whiteSpace: 'nowrap'
                            }}>
                {typeof genre === 'string' ? genre : (genre.name || '')}
              </span>
                        ))}
                        {genres.length > 2 && (
                            <span style={{
                                background: 'rgba(255, 255, 255, 0.1)',
                                color: 'var(--gray)',
                                padding: '4px 8px',
                                borderRadius: '15px',
                                fontSize: '12px'
                            }}>
                +{genres.length - 2}
              </span>
                        )}
                    </div>
                )}

                {movie.comment && movie.comment.trim() && (
                    <div className="movie-comment" style={{
                        marginTop: '8px',
                        padding: '10px',
                        background: 'rgba(255, 255, 255, 0.03)',
                        borderRadius: '8px',
                        borderLeft: '3px solid var(--primary)',
                        overflow: 'hidden'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '6px' }}>
                            <i className="fas fa-comment" style={{
                                color: 'var(--accent)',
                                marginRight: '8px',
                                fontSize: '12px'
                            }}></i>
                            <span style={{ fontWeight: '500', fontSize: '12px' }}>Мой комментарий:</span>
                        </div>
                        <p style={{
                            margin: 0,
                            fontSize: '13px',
                            color: 'rgba(255, 255, 255, 0.9)',
                            lineHeight: '1.4',
                            display: '-webkit-box',
                            WebkitLineClamp: 3,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden'
                        }}>
                            {movie.comment.length > 100 ?
                                `${movie.comment.substring(0, 100)}...` :
                                movie.comment
                            }
                        </p>
                    </div>
                )}

                {movie.createdAt && (
                    <div style={{
                        fontSize: '12px',
                        color: 'rgba(255, 255, 255, 0.5)',
                        marginTop: '8px',
                        marginBottom: '12px'
                    }}>
                        Добавлено: {new Date(movie.createdAt).toLocaleDateString('ru-RU')}
                    </div>
                )}

                <div className="movie-actions" style={{
                    display: 'flex',
                    gap: '10px',
                    marginTop: 'auto'
                }}>
                    <button
                        className="btn btn-outline"
                        onClick={(e) => {
                            e.stopPropagation();
                            if (onOpen) onOpen();
                        }}
                        style={{
                            flex: 1,
                            padding: '10px',
                            fontSize: '14px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '8px'
                        }}
                    >
                        <i className="fas fa-eye"></i> Подробнее
                    </button>
                    {onDelete && (
                        <button
                            className="btn btn-danger"
                            onClick={(e) => {
                                e.stopPropagation();
                                if (onDelete) onDelete(movie.id);
                            }}
                            style={{
                                flex: 1,
                                padding: '10px',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px'
                            }}
                        >
                            <i className="fas fa-trash"></i> Удалить
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}