import React, { useState } from 'react';

export default function Login({ onLogin, isOpen, onClose }) {
    const [open, setOpen] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const isControlled = typeof isOpen === 'boolean';
    const effectiveOpen = isControlled ? isOpen : open;

    function closeModal() {
        if (isControlled) {
            if (onClose) onClose();
        } else {
            setOpen(false);
        }
    }

    async function parseResponseSafely(response) {
        const text = await response.text();
        const contentType = (response.headers.get('content-type') || '').toLowerCase();
        if (contentType.includes('application/json')) {
            try { return JSON.parse(text); } catch (e) { return text; }
        }
        return text;
    }

    function extractTokenFromResponse(data) {
        if (!data) return null;
        if (typeof data === 'string') {
            if (data.split('.').length === 3) return data;
            return null;
        }
        if (typeof data === 'object') {
            if (data.token) return data.token;
            if (data.accessToken) return data.accessToken;
            if (data.data && (data.data.token || data.data.accessToken)) return data.data.token || data.data.accessToken;
            for (const k of Object.keys(data)) {
                if (typeof data[k] === 'string' && data[k].length > 20) return data[k];
            }
        }
        return null;
    }

    async function submit(e) {
        e.preventDefault();
        setError('');
        if (!username.trim() || !password) { setError('Введите имя пользователя и пароль'); return; }
        setLoading(true);
        try {
            const r = await fetch('http://localhost:8080/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ username: username.trim(), password })
            });
            const data = await parseResponseSafely(r);
            if (!r.ok) {
                const msg = (data && typeof data === 'object' && data.message) ? data.message : (data || 'Ошибка входа');
                throw new Error(msg);
            }
            const token = extractTokenFromResponse(data);
            if (!token) throw new Error('Не удалось получить токен из ответа сервера');
            localStorage.setItem('token', token);
            if (onLogin) onLogin(token);
            closeModal();
            setUsername(''); setPassword('');
        } catch (err) {
            console.error('Login error:', err);
            setError(err.message || 'Неверное имя пользователя или пароль');
        } finally {
            setLoading(false);
        }
    }

    if (isControlled && !isOpen) return null;

    if (!effectiveOpen && !isControlled) {
        return <button onClick={() => setOpen(true)} className="btn btn-outline" style={{ padding:'8px 16px' }}><i className="fas fa-sign-in-alt"></i> Войти</button>;
    }

    return (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.8)', backdropFilter:'blur(5px)', zIndex:2000, display:'flex', alignItems:'center', justifyContent:'center', padding:'20px' }}>
            <div style={{ background:'var(--card-bg)', backdropFilter:'blur(10px)', borderRadius:20, padding:30, width:'100%', maxWidth:400, boxShadow:'0 20px 40px rgba(0,0,0,0.4)', border:'1px solid rgba(255,255,255,0.1)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:25 }}>
                    <h3 style={{ margin:0, color:'var(--accent)', fontSize:24 }}>Вход в аккаунт</h3>
                    <button onClick={closeModal} style={{ background:'none', border:'none', color:'var(--light)', fontSize:20 }}><i className="fas fa-times"></i></button>
                </div>

                {error && <div style={{ background:'rgba(231,76,60,0.2)', color:'#ff6b6b', padding:12, borderRadius:10, marginBottom:20, border:'1px solid rgba(231,76,60,0.3)' }}>{error}</div>}

                <form onSubmit={submit}>
                    <div style={{ marginBottom:20 }}>
                        <label style={{ display:'block', marginBottom:8, color:'var(--accent)' }}>Имя пользователя</label>
                        <input type="text" value={username} onChange={e=>setUsername(e.target.value)} placeholder="Введите имя пользователя" required style={{ width:'100%', padding:'12px 16px', background:'rgba(255,255,255,0.1)', borderRadius:10, color:'var(--light)', border:'1px solid rgba(255,255,255,0.2)' }} />
                    </div>

                    <div style={{ marginBottom:25 }}>
                        <label style={{ display:'block', marginBottom:8, color:'var(--accent)' }}>Пароль</label>
                        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Введите пароль" required style={{ width:'100%', padding:'12px 16px', background:'rgba(255,255,255,0.1)', borderRadius:10, color:'var(--light)', border:'1px solid rgba(255,255,255,0.2)' }} />
                    </div>

                    <button type="submit" className="btn" style={{ width:'100%', padding:'14px', fontSize:16, fontWeight:600 }} disabled={loading}>{loading ? 'Вход...' : 'Войти'}</button>
                </form>

                <div style={{ marginTop:20, textAlign:'center', color:'var(--gray)' }}>
                    Нет аккаунта? <button onClick={() => { if (onClose) onClose(); if (onLogin) onLogin('showRegister'); }} style={{ background:'none', border:'none', color:'var(--primary)', cursor:'pointer' }}>Зарегистрироваться</button>
                </div>
            </div>
        </div>
    );
}