import React, { useState } from 'react';
import KinopoiskSearch from './KinopoiskSearch';

export default function AddMovieForm({ onAdd, onAddToWatchlist, showNotification, token }) {
  const [form, setForm] = useState({
    title: '',
    type: 'FILM',
    genre: '',
    year: '',
    dateWatched: '',
    rating: 0,
    comment: '',
    poster: ''
  });
  const [loading, setLoading] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    try {
      const newMovie = {
        id: Date.now(),
        ...form,
        rating: Number(form.rating),
        dateAdded: new Date().toISOString()
      };
      onAdd(newMovie);
      setForm({
        title: '',
        type: 'FILM',
        genre: '',
        year: '',
        dateWatched: '',
        rating: 0,
        comment: '',
        poster: ''
      });
      showNotification('Фильм успешно добавлен!', 'success');
    } catch (error) {
      showNotification('Ошибка при добавлении фильма', 'error');
    } finally {
      setLoading(false);
    }
  }

  function fillFromKinopoisk(data) {
    setForm(f => ({
      ...f,
      title: data.nameRu || data.nameEn || data.title || '',
      year: data.year || data.productionYear || data.releaseYear || '',
      poster: data.posterUrl || data.posterUrlPreview || f.poster,
      genre: data.genres ?
          (Array.isArray(data.genres) ?
              data.genres.map(g => g.genre || g.name || g).join(', ') :
              data.genres) :
          f.genre,
      type: data.type || f.type
    }));
    showNotification('Данные загружены из Kinopoisk!', 'success');
  }

  function handleAddToWatchlist() {
    const watchlistItem = {
      id: Date.now(),
      title: form.title,
      type: form.type,
      genre: form.genre,
      year: form.year,
      poster: form.poster,
      dateAdded: new Date().toISOString()
    };

    if (!form.title.trim()) {
      showNotification('Введите название для добавления в список', 'warning');
      return;
    }

    onAddToWatchlist(watchlistItem);
    setForm(f => ({ ...f, title: '', genre: '', year: '', poster: '' }));
    showNotification('Добавлено в "Хочу посмотреть"', 'success');
  }

  return (
      <div className="form-container">
        <div className="api-info">
          <i className="fas fa-info-circle"></i>
          <strong>Автозаполнение включено!</strong> Начните вводить название для поиска в Kinopoisk.
        </div>

        <KinopoiskSearch onSelect={fillFromKinopoisk} />

        {!token && (
            <div className="info-box" style={{
              background: 'rgba(255, 209, 102, 0.1)',
              padding: '15px',
              borderRadius: '10px',
              marginBottom: '20px',
              border: '1px solid rgba(255, 209, 102, 0.3)'
            }}>
              <i className="fas fa-info-circle" style={{ color: 'var(--accent)', marginRight: '8px' }}></i>
              <span>Работаете в локальном режиме. Войдите, чтобы сохранять фильмы на сервере и синхронизировать между устройствами.</span>
            </div>
        )}

        <form onSubmit={handleSubmit} id="add-movie-form">
          <div className="form-grid">
            <div className="form-group">
              <label>Название *</label>
              <input
                  required
                  value={form.title}
                  onChange={e => setForm({...form, title: e.target.value})}
                  placeholder="Введите название фильма или сериала"
              />
            </div>

            <div className="form-group">
              <label>Тип *</label>
              <select
                  value={form.type}
                  onChange={e => setForm({...form, type: e.target.value})}
              >
                <option value="FILM">Фильм</option>
                <option value="TV_SERIES">Сериал</option>
                <option value="MINI_SERIES">Мини-сериал</option>
                <option value="TV_SHOW">ТВ-шоу</option>
              </select>
            </div>

            <div className="form-group">
              <label>Жанр</label>
              <input
                  value={form.genre}
                  onChange={e => setForm({...form, genre: e.target.value})}
                  placeholder="драма, комедия, боевик"
              />
            </div>

            <div className="form-group">
              <label>Год выпуска</label>
              <input
                  type="number"
                  value={form.year}
                  onChange={e => setForm({...form, year: e.target.value})}
                  min="1900"
                  max="2030"
                  placeholder="2023"
              />
            </div>

            <div className="form-group">
              <label>Дата просмотра</label>
              <input
                  type="date"
                  value={form.dateWatched}
                  onChange={e => setForm({...form, dateWatched: e.target.value})}
              />
            </div>

            <div className="form-group">
              <label>Оценка</label>
              <div className="rating" style={{ justifyContent: 'flex-start' }}>
                {[5, 4, 3, 2, 1].map(v => (
                    <label key={v} style={{ marginRight: '6px' }}>
                      <input
                          type="radio"
                          name="rating"
                          value={v}
                          checked={Number(form.rating) === v}
                          onChange={() => setForm({...form, rating: v})}
                          style={{ display: 'none' }}
                      />
                      <span style={{
                        fontSize: '20px',
                        color: Number(form.rating) >= v ? '#ffd166' : '#666',
                        cursor: 'pointer'
                      }}>
                    ★
                  </span>
                    </label>
                ))}
              </div>
            </div>

            <div className="form-group full-width">
              <label>Мои впечатления</label>
              <textarea
                  value={form.comment}
                  onChange={e => setForm({...form, comment: e.target.value})}
                  placeholder="Поделитесь вашими впечатлениями о фильме..."
                  rows="4"
              />
            </div>

            <div className="form-group full-width">
              <label>Ссылка на постер</label>
              <input
                  type="url"
                  value={form.poster}
                  onChange={e => setForm({...form, poster: e.target.value})}
                  placeholder="https://example.com/poster.jpg"
              />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px', marginTop: '24px', flexWrap: 'wrap' }}>
            <button
                className="btn"
                type="submit"
                disabled={loading}
                style={{
                  padding: '12px 24px',
                  fontSize: '16px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  flex: 1,
                  minWidth: '200px'
                }}
            >
              {loading ? (
                  <>
                    <div className="spinner" style={{ width: '16px', height: '16px' }}></div>
                    Добавление...
                  </>
              ) : (
                  <>
                    <i className="fas fa-plus"></i>
                    Добавить в дневник
                  </>
              )}
            </button>

            <button
                type="button"
                className="btn btn-outline"
                onClick={handleAddToWatchlist}
                disabled={loading || !form.title.trim()}
                style={{
                  padding: '12px 24px',
                  fontSize: '16px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  flex: 1,
                  minWidth: '200px'
                }}
            >
              <i className="fas fa-bookmark"></i>
              Добавить в "Хочу посмотреть"
            </button>
          </div>

          {!form.title.trim() && (
              <div style={{
                marginTop: '15px',
                padding: '10px',
                background: 'rgba(255, 255, 255, 0.05)',
                borderRadius: '8px',
                fontSize: '14px',
                color: 'var(--gray)',
                textAlign: 'center'
              }}>
                <i className="fas fa-lightbulb" style={{ marginRight: '8px' }}></i>
                Начните вводить название или используйте поиск Kinopoisk для автозаполнения
              </div>
          )}
        </form>
      </div>
  );
}