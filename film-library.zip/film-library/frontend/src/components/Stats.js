import React, { useState, useEffect } from 'react';
import { statsApi } from './api';

export default function Stats({ movies, watchlist, onReset, token }) {
    const [serverStats, setServerStats] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Загружаем статистику с сервера, если пользователь авторизован
    useEffect(() => {
        if (token) {
            fetchServerStats();
        }
    }, [token]);

    const fetchServerStats = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await statsApi.getStats(token);
            setServerStats(data);
        } catch (err) {
            console.error('Error fetching stats:', err);
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    // Локальная статистика (для незалогиненных пользователей)
    const total = movies.length;
    const films = movies.filter(m => m.type === 'FILM' || m.type === 'film').length;
    const series = movies.filter(m => m.type === 'TV_SERIES' || m.type === 'TV_SHOW' || m.type === 'MINI_SERIES').length;
    const watchlistCount = watchlist.length;
    const totalRating = movies.reduce((s, m) => s + (Number(m.rating) || 0), 0);
    const avgRating = total > 0 ? (totalRating / total).toFixed(1) : '0.0';

    const genreStats = {};
    movies.forEach(m => {
        if (m.genre) {
            if (Array.isArray(m.genre)) {
                m.genre.forEach(g => {
                    if (g && g.name) genreStats[g.name] = (genreStats[g.name] || 0) + 1;
                });
            } else if (typeof m.genre === 'string') {
                m.genre.split(',').map(g => g.trim()).forEach(g => {
                    if (g) genreStats[g] = (genreStats[g] || 0) + 1;
                });
            }
        }
    });

    const favorite = Object.keys(genreStats).length ?
        Object.entries(genreStats).sort((a, b) => b[1] - a[1])[0][0] : '-';

    const topGenres = Object.entries(genreStats)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6);

    const stats = token && serverStats ? serverStats : {
        totalMovies: total,
        averageRating: avgRating,
        filmsCount: films,
        seriesCount: series,
        watchlistCount,
        favoriteGenre: favorite
    };

    return (
        <div>
            <h1 className="page-title">Моя статистика</h1>

            {!token && (
                <div className="info-box" style={{
                    background: 'rgba(255, 209, 102, 0.1)',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '25px',
                    border: '1px solid rgba(255, 209, 102, 0.3)'
                }}>
                    <i className="fas fa-info-circle" style={{ color: 'var(--accent)', marginRight: '8px' }}></i>
                    <span>Статистика рассчитывается на основе локальных данных. Войдите, чтобы получить полную статистику.</span>
                </div>
            )}

            {token && loading && (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                    <div className="spinner" style={{ width: '40px', height: '40px', margin: '0 auto 20px' }}></div>
                    <p>Загрузка статистики...</p>
                </div>
            )}

            {token && error && (
                <div style={{
                    background: 'rgba(231, 76, 60, 0.1)',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '25px',
                    border: '1px solid rgba(231, 76, 60, 0.3)'
                }}>
                    <p style={{ color: '#ff6b6b', margin: 0 }}>
                        <i className="fas fa-exclamation-circle" style={{ marginRight: '8px' }}></i>
                        {error}
                    </p>
                </div>
            )}

            {(!token || serverStats) && (
                <>
                    <div className="stats-grid">
                        <div className="stat-card">
                            <div className="stat-value">{stats.totalMovies || 0}</div>
                            <div className="stat-label">Всего просмотрено</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-value">{stats.averageRating || '0.0'}</div>
                            <div className="stat-label">Средняя оценка</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-value">{stats.filmsCount || films}</div>
                            <div className="stat-label">Фильмы</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-value">{stats.seriesCount || series}</div>
                            <div className="stat-label">Сериалы</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-value">{stats.watchlistCount || watchlistCount}</div>
                            <div className="stat-label">В списке ожидания</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-value">{stats.favoriteGenre || favorite}</div>
                            <div className="stat-label">Любимый жанр</div>
                        </div>
                    </div>

                    <h2 style={{ marginTop: '40px', marginBottom: '20px' }}>Любимые жанры</h2>
                    <div className="genre-stats" style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                        gap: '15px'
                    }}>
                        {topGenres.length === 0 ? (
                            <div className="empty-state" style={{ gridColumn: '1 / -1', padding: '40px' }}>
                                <i className="fas fa-film"></i>
                                <p>Жанры не указаны</p>
                            </div>
                        ) : topGenres.map(([g, c]) => (
                            <div className="stat-card" key={g}>
                                <div className="stat-value">{c}</div>
                                <div className="stat-label">{g}</div>
                            </div>
                        ))}
                    </div>

                    <div style={{ textAlign: 'center', marginTop: '40px', paddingTop: '20px', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
                        <button
                            className="btn btn-danger"
                            onClick={onReset}
                            style={{ padding: '12px 24px', fontSize: '16px' }}
                        >
                            <i className="fas fa-trash"></i> Сбросить все данные
                        </button>

                        {token && (
                            <button
                                className="btn btn-outline"
                                onClick={fetchServerStats}
                                style={{ marginLeft: '15px', padding: '12px 24px', fontSize: '16px' }}
                            >
                                <i className="fas fa-sync-alt"></i> Обновить статистику
                            </button>
                        )}
                    </div>
                </>
            )}
        </div>
    );
}