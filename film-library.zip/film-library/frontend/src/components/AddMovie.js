import React, { useState } from 'react';

const KINO = {
  baseUrl: 'https://kinopoiskapiunofficial.tech/api/v2.2/films',
  apiKey: '8c8e1a50-6322-4135-8875-5d40a5420d86',
  headers: {
    'X-API-KEY': '8c8e1a50-6322-4135-8875-5d40a5420d86',
    'Content-Type': 'application/json'
  }
};

export default function AddMovie({ onAdd }) {
  const [title, setTitle] = useState('');
  const [type, setType] = useState('FILM');
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [dateWatched, setDateWatched] = useState('');
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [poster, setPoster] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loadingSearch, setLoadingSearch] = useState(false);

  async function searchKinopoisk(q) {
    if (!q || q.length < 2) return;
    setLoadingSearch(true);
    try {
      const res = await fetch(`${KINO.baseUrl}?keyword=${encodeURIComponent(q)}`, { headers: KINO.headers });
      if (!res.ok) throw new Error('Ошибка при поиске');
      const data = await res.json();
      setResults(data.items || []);
    } catch (e) {
      console.error(e);
      setResults([]);
    } finally {
      setLoadingSearch(false);
    }
  }

  function fillFrom(item) {
    setTitle(item.nameRu || item.nameEn || '');
    setType(item.type || 'FILM');
    setYear(item.year || '');
    setPoster(item.posterUrl || item.posterUrlPreview || '');
    setGenre(item.genres ? item.genres.map(g=>g.genre).join(', ') : '');
    setResults([]);
    setSearchQuery('');
    alert('Данные загружены из Kinopoisk!');
  }

  function submit(e) {
    e.preventDefault();
    const newMovie = {
      id: Date.now(),
      title,
      type,
      genre,
      year,
      dateWatched: dateWatched || new Date().toISOString().split('T')[0],
      rating: Number(rating),
      comment,
      poster,
      dateAdded: new Date().toISOString()
    };
    onAdd(newMovie);
    // reset
    setTitle(''); setType('FILM'); setGenre(''); setYear(''); setDateWatched(''); setRating(0); setComment(''); setPoster('');
  }

  return (
    <section>
      <h1 style={{textAlign:'center'}}>Добавить фильм или сериал</h1>

      <div className="form-container" style={{marginTop:12}}>
        <div style={{marginBottom:12, color:'#ddd'}}>Автозаполнение: начните вводить название для поиска через Kinopoisk API</div>

        <div style={{marginBottom:12}}>
          <input placeholder="Поиск в Kinopoisk..." value={searchQuery} onChange={e=>{ setSearchQuery(e.target.value); if (e.target.value.length>=2) setTimeout(()=>searchKinopoisk(e.target.value), 400); }} style={{width:'100%'}} />
          {loadingSearch && <div style={{marginTop:6}}>Поиск...</div>}
          {results.length>0 && (
            <div style={{marginTop:8,background:'#222',padding:8,borderRadius:8}}>
              {results.slice(0,8).map(item => (
                <div key={item.filmId || item.kinopoiskId} style={{display:'flex',gap:12,padding:8,cursor:'pointer'}} onClick={()=>fillFrom(item)}>
                  <img src={item.posterUrlPreview || ''} alt="" style={{width:40,height:60,objectFit:'cover'}} />
                  <div>
                    <div style={{fontWeight:600}}>{item.nameRu || item.nameEn}</div>
                    <div style={{fontSize:13,color:'#888'}}>{item.year} • {item.type}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <form onSubmit={submit}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div>
              <label>Название *</label>
              <input required value={title} onChange={e=>setTitle(e.target.value)} />
            </div>
            <div>
              <label>Тип *</label>
              <select value={type} onChange={e=>setType(e.target.value)}>
                <option value="FILM">Фильм</option>
                <option value="TV_SERIES">Сериал</option>
                <option value="MINI_SERIES">Мини-сериал</option>
                <option value="TV_SHOW">ТВ-шоу</option>
              </select>
            </div>

            <div>
              <label>Жанр</label>
              <input value={genre} onChange={e=>setGenre(e.target.value)} placeholder="драма, комедия" />
            </div>

            <div>
              <label>Год</label>
              <input type="number" min="1900" max="2030" value={year} onChange={e=>setYear(e.target.value)} />
            </div>

            <div>
              <label>Дата просмотра</label>
              <input type="date" value={dateWatched} onChange={e=>setDateWatched(e.target.value)} />
            </div>

            <div>
              <label>Оценка</label>
              <select value={rating} onChange={e=>setRating(e.target.value)}>
                <option value={0}>0</option>
                <option value={1}>1</option>
                <option value={2}>2</option>
                <option value={3}>3</option>
                <option value={4}>4</option>
                <option value={5}>5</option>
              </select>
            </div>

            <div style={{gridColumn:'1 / -1'}}>
              <label>Мои впечатления</label>
              <textarea value={comment} onChange={e=>setComment(e.target.value)} />
            </div>

            <div style={{gridColumn:'1 / -1'}}>
              <label>Ссылка на постер</label>
              <input type="url" value={poster} onChange={e=>setPoster(e.target.value)} placeholder="https://example.com/poster.jpg" />
            </div>
          </div>

          <div style={{marginTop:12}}>
            <button className="btn btn-accent" type="submit" style={{width:'100%'}}>Добавить в дневник</button>
          </div>
        </form>
      </div>
    </section>
  );
}