import React, { useState, useRef } from 'react';

/**
 * Simple Kinopoisk search component using the unofficial API.
 * NOTE: The app included an API key in indexnew.html. You can replace the default API key below with your key or
 * move it to environment variable and inject at build time.
 */
const DEFAULT = {
  baseUrl: 'https://kinopoiskapiunofficial.tech/api/v2.2/films',
  apiKey: '8c8e1a50-6322-4135-8875-5d40a5420d86'
};

export default function KinopoiskSearch({ onSelect }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const timeoutRef = useRef();

  async function search(q) {
    setLoading(true);
    try {
      const res = await fetch(`${DEFAULT.baseUrl}?keyword=${encodeURIComponent(q)}`, {
        headers: { 'X-API-KEY': DEFAULT.apiKey, 'Content-Type': 'application/json' }
      });
      if (!res.ok) throw new Error('API error');
      const data = await res.json();
      setResults(data.items || []);
    } catch (err) {
      console.error(err);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  function onChange(e) {
    const v = e.target.value;
    setQuery(v);
    clearTimeout(timeoutRef.current);
    if (v.trim().length < 2) { setResults([]); return; }
    timeoutRef.current = setTimeout(()=>search(v.trim()), 500);
  }

  return (
    <div style={{marginBottom:16, position:'relative'}} className="search-container">
      <input className="search-input" placeholder="Начните вводить название для поиска..." value={query} onChange={onChange} />
      <div className="search-results" style={{display: results.length || loading ? 'block' : 'none', position:'absolute', zIndex:100, left:0, right:0}}>
        {loading && <div className="search-result-item"><div className="spinner"></div> Поиск...</div>}
        {!loading && results.length === 0 && query.length>=2 && <div className="search-result-item">Ничего не найдено</div>}
        {!loading && results.slice(0,8).map(item => (
          <div key={item.filmId || item.kinopoiskId || item.id} className="search-result-item" onClick={() => { onSelect(item); setResults([]); setQuery(''); }}>
            <img src={item.posterUrlPreview || 'https://via.placeholder.com/40x60'} className="search-result-poster" alt={item.nameRu || item.nameEn} />
            <div className="search-result-info">
              <div className="search-result-title">{item.nameRu || item.nameEn || 'Без названия'}</div>
              <div className="search-result-meta">
                <span>{item.type}</span> {item.year ? <span>• {item.year}</span> : null}
                {item.rating && <span style={{marginLeft:8}} className="kp-rating">Р: {item.rating}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}