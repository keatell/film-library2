import React from 'react';

export default function Home({ movies, onOpenDetail }) {
  const recent = movies.slice(0, 6);
  return (
    <section className="page active">
      <div className="hero">
        <h1 style={{fontSize:48,marginBottom:12}}>Ваш личный кино-дневник</h1>
        <p style={{maxWidth:760,margin:'0 auto 12px',color:'rgba(255,255,255,0.8)'}}>Отслеживайте всё, что вы посмотрели, делитесь впечатлениями и открывайте для себя новые фильмы и сериалы</p>
      </div>

      <h2 style={{textAlign:'center'}}>Недавно добавленные</h2>
      <div className="movies-grid" style={{marginTop:16}}>
        {recent.length === 0 ? (
          <div className="empty-state">
            <i className="fas fa-film" style={{fontSize:48,display:'block',marginBottom:8}}></i>
            <h3>Пока нет добавленных фильмов</h3>
            <p>Начните добавлять фильмы и сериалы, чтобы они появились здесь</p>
          </div>
        ) : recent.map(m => (
          <div key={m.id} className="movie-card" style={{cursor:'pointer'}} onClick={() => onOpenDetail(m)}>
            <img className="movie-poster" src={m.poster || `https://via.placeholder.com/300x400/1a1a2e/6a11cb?text=No+Image`} alt={m.title} />
            <div className="movie-info">
              <div className="movie-title">{m.title} {m.year ? `(${m.year})` : ''}</div>
              <div style={{fontSize:13,color:'#bbb'}}>{(m.genre||'').split(',').slice(0,2).join(', ')}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}