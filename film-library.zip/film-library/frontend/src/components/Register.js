import React, { useState } from 'react';

export default function Register({ onLogin, isOpen, onClose }) {
    const [open, setOpen] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const isControlled = typeof isOpen === 'boolean';
    const effectiveOpen = isControlled ? isOpen : open;

    function closeModal() {
        if (isControlled) {
            if (onClose) onClose();
        } else {
            setOpen(false);
        }
    }

    async function parseResponseSafely(response) {
        const text = await response.text();
        const contentType = (response.headers.get('content-type') || '').toLowerCase();
        if (contentType.includes('application/json')) {
            try { return JSON.parse(text); } catch (e) { return text; }
        }
        return text;
    }

    function extractTokenFromResponse(data) {
        if (!data) return null;
        if (typeof data === 'string') {
            if (data.split('.').length === 3) return data;
            return null;
        }
        if (typeof data === 'object') {
            if (data.token) return data.token;
            if (data.accessToken) return data.accessToken;
            if (data.data && (data.data.token || data.data.accessToken)) return data.data.token || data.data.accessToken;
            for (const k of Object.keys(data)) {
                if (typeof data[k] === 'string' && data[k].length > 20) return data[k];
            }
        }
        return null;
    }

    async function submit(e) {
        e.preventDefault();
        setError('');

        if (!username.trim() || !password) { setError('Введите имя пользователя и пароль'); return; }
        if (password.length < 6) { setError('Пароль должен быть не менее 6 символов'); return; }
        if (password !== confirmPassword) { setError('Пароли не совпадают'); return; }

        setLoading(true);
        try {
            const regResp = await fetch('http://localhost:8080/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ username: username.trim(), password })
            });

            const regData = await parseResponseSafely(regResp);
            if (!regResp.ok) {
                const msg = (regData && typeof regData === 'object' && regData.message) ? regData.message : (regData || 'Ошибка регистрации');
                throw new Error(msg);
            }

            // Закрываем модалку сразу после успешной регистрации
            closeModal();

            // Пытаемся авто-входить. Если токен придёт — используем; если нет — перенаправим на главную
            try {
                const loginResp = await fetch('http://localhost:8080/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify({ username: username.trim(), password })
                });

                const loginData = await parseResponseSafely(loginResp);
                if (!loginResp.ok) {
                    alert((loginData && typeof loginData === 'string') ? loginData : 'Регистрация успешна. Войдите в систему.');
                    window.location.href = '/';
                    return;
                }

                const token = extractTokenFromResponse(loginData);
                if (token) {
                    localStorage.setItem('token', token);
                    if (onLogin) onLogin(token);
                    setUsername(''); setPassword(''); setConfirmPassword('');
                } else {
                    alert('Регистрация выполнена. Пожалуйста, войдите в систему.');
                    window.location.href = '/';
                }
            } catch (loginErr) {
                console.warn('Auto-login failed:', loginErr);
                alert('Регистрация выполнена. Попробуйте войти вручную.');
                window.location.href = '/';
            }
        } catch (err) {
            console.error('Registration error:', err);
            setError(err.message || 'Ошибка регистрации. Попробуйте позже.');
        } finally {
            setLoading(false);
        }
    }

    // Если компонент контролируется и isOpen === false — не рендерим ничего
    if (isControlled && !isOpen) return null;

    // Неконтролируемый режим: показываем кнопку, если не открыт
    if (!effectiveOpen && !isControlled) {
        return (
            <button onClick={() => setOpen(true)} className="btn btn-outline" style={{ padding: '8px 16px', fontSize: '14px' }}>
                <i className="fas fa-user-plus"></i> Регистрация
            </button>
        );
    }

    // Рендер модалки
    return (
        <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.8)', backdropFilter:'blur(5px)', zIndex:2000, display:'flex', alignItems:'center', justifyContent:'center', padding:'20px' }}>
            <div style={{ background:'var(--card-bg)', backdropFilter:'blur(10px)', borderRadius:20, padding:30, width:'100%', maxWidth:400, boxShadow:'0 20px 40px rgba(0,0,0,0.4)', border:'1px solid rgba(255,255,255,0.1)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:25 }}>
                    <h3 style={{ margin:0, color:'var(--accent)', fontSize:24 }}>Регистрация</h3>
                    <button onClick={closeModal} style={{ background:'none', border:'none', color:'var(--light)', fontSize:20, cursor:'pointer' }}><i className="fas fa-times"></i></button>
                </div>

                {error && <div style={{ background:'rgba(231,76,60,0.2)', color:'#ff6b6b', padding:12, borderRadius:10, marginBottom:20, border:'1px solid rgba(231,76,60,0.3)' }}><i className="fas fa-exclamation-circle" style={{marginRight:8}}></i>{error}</div>}

                <form onSubmit={submit}>
                    <div style={{ marginBottom:20 }}>
                        <label style={{ display:'block', marginBottom:8, color:'var(--accent)' }}>Имя пользователя</label>
                        <input type="text" value={username} onChange={e=>setUsername(e.target.value)} placeholder="Введите имя пользователя" required style={{ width:'100%', padding:'12px 16px', background:'rgba(255,255,255,0.1)', borderRadius:10, color:'var(--light)', border:'1px solid rgba(255,255,255,0.2)' }} />
                    </div>

                    <div style={{ marginBottom:20 }}>
                        <label style={{ display:'block', marginBottom:8, color:'var(--accent)' }}>Пароль (мин. 6 символов)</label>
                        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Введите пароль" required minLength="6" style={{ width:'100%', padding:'12px 16px', background:'rgba(255,255,255,0.1)', borderRadius:10, color:'var(--light)', border:'1px solid rgba(255,255,255,0.2)' }} />
                    </div>

                    <div style={{ marginBottom:25 }}>
                        <label style={{ display:'block', marginBottom:8, color:'var(--accent)' }}>Подтвердите пароль</label>
                        <input type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} placeholder="Повторите пароль" required minLength="6" style={{ width:'100%', padding:'12px 16px', background:'rgba(255,255,255,0.1)', borderRadius:10, color:'var(--light)', border:'1px solid rgba(255,255,255,0.2)' }} />
                    </div>

                    <button type="submit" className="btn" style={{ width:'100%', padding:'14px', fontSize:16, fontWeight:600 }} disabled={loading}>
                        {loading ? 'Регистрация...' : 'Зарегистрироваться'}
                    </button>
                </form>

                <div style={{ marginTop:20, textAlign:'center', color:'var(--gray)' }}>
                    Уже есть аккаунт? <button onClick={() => { if (onClose) onClose(); if (onLogin) onLogin('showLogin'); }} style={{ background:'none', border:'none', color:'var(--primary)', cursor:'pointer', textDecoration:'underline' }}>Войти</button>
                </div>
            </div>
        </div>
    );
}