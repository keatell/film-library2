import React, { useState, useEffect } from 'react';
import Login from './Login';
import Register from './Register';

export default function Header({ onNavigate, currentPage, onExport, user, onLogout, onLogin }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Слушаем события для открытия модалок
  useEffect(() => {
    const handleShowLoginModal = () => setShowLoginModal(true);
    const handleShowRegisterModal = () => setShowRegisterModal(true);

    window.addEventListener('showLoginModal', handleShowLoginModal);
    window.addEventListener('showRegisterModal', handleShowRegisterModal);

    return () => {
      window.removeEventListener('showLoginModal', handleShowLoginModal);
      window.removeEventListener('showRegisterModal', handleShowRegisterModal);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuOpen && !e.target.closest('.header-content') && !e.target.closest('.burger-menu')) {
        setMenuOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [menuOpen]);

  const handleLoginSuccess = (tokenOrAction) => {
    console.log('Login success callback:', tokenOrAction);
    if (tokenOrAction === 'showRegister') {
      setShowLoginModal(false);
      setShowRegisterModal(true);
    } else if (tokenOrAction === 'showLogin') {
      setShowRegisterModal(false);
      setShowLoginModal(true);
    } else {
      setShowLoginModal(false);
      setShowRegisterModal(false);
      if (onLogin) {
        onLogin(tokenOrAction);
      }
    }
  };

  const navLinks = [
    { id: 'home', label: 'Главная', icon: 'fas fa-home' },
    { id: 'movies', label: 'Мои фильмы', icon: 'fas fa-film' },
    { id: 'watchlist', label: 'Хочу посмотреть', icon: 'fas fa-bookmark' },
    { id: 'add', label: 'Добавить', icon: 'fas fa-plus-circle' },
    { id: 'stats', label: 'Статистика', icon: 'fas fa-chart-bar' },
    ...(user ? [{ id: 'profile', label: 'Профиль', icon: 'fas fa-user' }] : [])
  ];

  const handleNavClick = (pageId) => {
    onNavigate(pageId);
    if (isMobile) {
      setMenuOpen(false);
    }
  };

  console.log('Header render - User:', user, 'ShowLoginModal:', showLoginModal);

  return (
      <>
        <header className="header" style={{
          background: 'rgba(26, 26, 46, 0.95)',
          backdropFilter: 'blur(10px)',
          position: 'sticky',
          top: 0,
          zIndex: 1000,
          boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
          borderBottom: '1px solid rgba(255, 255, 255, 0.05)',
          height: '60px'
        }}>
          <div className="main-container" style={{ height: '100%' }}>
            <div className="header-content" style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              height: '100%',
              position: 'relative'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                {isMobile && (
                    <button
                        className="burger-menu"
                        onClick={(e) => {
                          e.stopPropagation();
                          setMenuOpen(!menuOpen);
                        }}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: 'var(--light)',
                          fontSize: '24px',
                          cursor: 'pointer',
                          padding: '8px',
                          borderRadius: '4px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'var(--transition)'
                        }}
                    >
                      <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`}></i>
                    </button>
                )}

                <div
                    className="logo"
                    onClick={() => onNavigate('home')}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      textDecoration: 'none',
                      cursor: 'pointer'
                    }}
                >
                  <i className="fas fa-film" style={{
                    fontSize: '24px',
                    color: '#ffd166',
                    background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))',
                    padding: '8px',
                    borderRadius: '10px'
                  }}></i>
                  <span style={{
                    fontSize: '20px',
                    fontWeight: '700',
                    background: 'linear-gradient(to right, var(--primary), var(--primary-dark))',
                    WebkitBackgroundClip: 'text',
                    backgroundClip: 'text',
                    color: 'transparent'
                  }}>CineDairy</span>
                </div>
              </div>

              {!isMobile && (
                  <nav style={{ display: 'flex', gap: '5px' }}>
                    {navLinks.map(link => (
                        <a
                            key={link.id}
                            href="#"
                            onClick={(e) => { e.preventDefault(); handleNavClick(link.id); }}
                            className={currentPage === link.id ? 'active' : ''}
                            style={{
                              color: currentPage === link.id ? 'var(--accent)' : 'var(--light)',
                              textDecoration: 'none',
                              padding: '8px 16px',
                              borderRadius: '20px',
                              fontSize: '14px',
                              fontWeight: '500',
                              transition: 'var(--transition)',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              background: currentPage === link.id ? 'rgba(255, 255, 255, 0.1)' : 'transparent'
                            }}
                        >
                          <i className={link.icon} style={{ fontSize: '14px' }}></i>
                          {link.label}
                        </a>
                    ))}
                  </nav>
              )}

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                {user && !isMobile && (
                    <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px',
                          padding: '6px 12px',
                          background: 'rgba(255, 255, 255, 0.05)',
                          borderRadius: '20px',
                          cursor: 'pointer',
                          transition: 'var(--transition)'
                        }}
                        onClick={() => onNavigate('profile')}
                    >
                      <i className="fas fa-user-circle" style={{ color: 'var(--accent)' }}></i>
                      <span style={{
                        fontSize: '14px',
                        color: 'var(--accent)',
                        fontWeight: '500'
                      }}>{user.username}</span>
                    </div>
                )}

                <div style={{ display: 'flex', gap: '8px' }}>
                  {user ? (
                      <>
                        <button
                            className="btn btn-outline"
                            onClick={onLogout}
                            style={{
                              padding: '8px 16px',
                              fontSize: '14px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px'
                            }}
                        >
                          <i className="fas fa-sign-out-alt"></i>
                          {!isMobile && 'Выйти'}
                        </button>
                      </>
                  ) : (
                      <>
                        <button
                            onClick={() => setShowLoginModal(true)}
                            className="btn btn-outline"
                            style={{
                              padding: '8px 16px',
                              fontSize: '14px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px'
                            }}
                        >
                          <i className="fas fa-sign-in-alt"></i>
                          {!isMobile && 'Войти'}
                        </button>
                        <button
                            onClick={() => setShowRegisterModal(true)}
                            className="btn btn-outline"
                            style={{
                              padding: '8px 16px',
                              fontSize: '14px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px'
                            }}
                        >
                          <i className="fas fa-user-plus"></i>
                          {!isMobile && 'Регистрация'}
                        </button>
                      </>
                  )}

                  <button
                      className="btn btn-outline"
                      onClick={onExport}
                      title="Экспорт данных"
                      style={{
                        padding: '8px',
                        width: '36px',
                        height: '36px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                  >
                    <i className="fas fa-download"></i>
                  </button>
                </div>
              </div>

              {isMobile && menuOpen && (
                  <div style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    background: 'rgba(26, 26, 46, 0.98)',
                    backdropFilter: 'blur(20px)',
                    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                    boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
                    zIndex: 1000
                  }}>
                    {user && (
                        <div style={{
                          padding: '20px',
                          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                          background: 'rgba(255, 255, 255, 0.05)'
                        }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <div style={{
                              width: '40px',
                              height: '40px',
                              borderRadius: '50%',
                              background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              fontSize: '20px'
                            }}>
                              <i className="fas fa-user" style={{ color: 'white' }}></i>
                            </div>
                            <div>
                              <div style={{
                                fontSize: '16px',
                                fontWeight: '600',
                                color: 'var(--light)'
                              }}>{user.username}</div>
                              <div style={{
                                fontSize: '12px',
                                color: 'var(--gray)',
                                marginTop: '2px'
                              }}>{user.movieCount || 0} фильмов</div>
                            </div>
                          </div>
                        </div>
                    )}

                    <div style={{ padding: '10px 0' }}>
                      {navLinks.map(link => (
                          <a
                              key={link.id}
                              href="#"
                              onClick={(e) => { e.preventDefault(); handleNavClick(link.id); }}
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '15px',
                                padding: '15px 20px',
                                color: currentPage === link.id ? 'var(--accent)' : 'var(--light)',
                                textDecoration: 'none',
                                transition: 'var(--transition)',
                                background: currentPage === link.id ? 'rgba(106, 17, 203, 0.2)' : 'transparent',
                                borderLeft: currentPage === link.id ? '4px solid var(--accent)' : '4px solid transparent'
                              }}
                          >
                            <i className={link.icon} style={{
                              fontSize: '18px',
                              width: '24px',
                              textAlign: 'center'
                            }}></i>
                            <span style={{ fontSize: '16px' }}>{link.label}</span>
                            {currentPage === link.id && (
                                <i className="fas fa-chevron-right" style={{
                                  marginLeft: 'auto',
                                  fontSize: '12px',
                                  color: 'var(--accent)'
                                }}></i>
                            )}
                          </a>
                      ))}
                    </div>

                    {!user && (
                        <div style={{
                          padding: '20px',
                          borderTop: '1px solid rgba(255, 255, 255, 0.1)',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '10px'
                        }}>
                          <button
                              className="btn"
                              onClick={() => {
                                setMenuOpen(false);
                                setShowLoginModal(true);
                              }}
                              style={{
                                width: '100%',
                                padding: '12px',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px'
                              }}
                          >
                            <i className="fas fa-sign-in-alt"></i>
                            Войти
                          </button>
                          <button
                              className="btn btn-outline"
                              onClick={() => {
                                setMenuOpen(false);
                                setShowRegisterModal(true);
                              }}
                              style={{
                                width: '100%',
                                padding: '12px',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '8px'
                              }}
                          >
                            <i className="fas fa-user-plus"></i>
                            Регистрация
                          </button>
                        </div>
                    )}

                    <div style={{
                      padding: '20px',
                      borderTop: '1px solid rgba(255, 255, 255, 0.1)'
                    }}>
                      <div style={{ display: 'flex', gap: '10px' }}>
                        <button
                            className="btn btn-outline"
                            onClick={() => {
                              onExport();
                              setMenuOpen(false);
                            }}
                            style={{
                              flex: 1,
                              padding: '12px',
                              fontSize: '14px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '8px'
                            }}
                        >
                          <i className="fas fa-download"></i>
                          Экспорт
                        </button>

                        {user && (
                            <button
                                className="btn btn-danger"
                                onClick={() => {
                                  onLogout();
                                  setMenuOpen(false);
                                }}
                                style={{
                                  flex: 1,
                                  padding: '12px',
                                  fontSize: '14px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  gap: '8px'
                                }}
                            >
                              <i className="fas fa-sign-out-alt"></i>
                              Выйти
                            </button>
                        )}
                      </div>
                    </div>
                  </div>
              )}
            </div>
          </div>
        </header>

        <Login
            isOpen={showLoginModal}
            onLogin={handleLoginSuccess}
            onClose={() => setShowLoginModal(false)}
        />
        <Register
            isOpen={showRegisterModal}
            onLogin={handleLoginSuccess}
            onClose={() => setShowRegisterModal(false)}
        />
      </>
  );
}