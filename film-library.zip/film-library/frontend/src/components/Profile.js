import React, { useState, useEffect } from 'react';
import { userApi, movieApi, watchlistApi } from './api';

export default function Profile({ user, token, onLogout }) {
    const [profile, setProfile] = useState(user);
    const [userMovies, setUserMovies] = useState([]);
    const [userWatchlist, setUserWatchlist] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statsLoading, setStatsLoading] = useState(false);
    const [activeTab, setActiveTab] = useState('overview');
    const [error, setError] = useState(null);

    useEffect(() => {
        if (token && user) {
            fetchUserData();
        }
    }, [token, user]);

    const fetchUserData = async () => {
        setLoading(true);
        setError(null);

        try {
            // Загружаем профиль
            const profileData = await userApi.getProfile(token);
            setProfile(profileData);

            // Загружаем фильмы пользователя
            const moviesData = await movieApi.getMyMovies(token);
            setUserMovies(moviesData);

            // Загружаем список ожидания
            try {
                const watchlistData = await watchlistApi.getWatchlist(token);
                setUserWatchlist(watchlistData);
            } catch (watchlistError) {
                console.warn('Watchlist not available:', watchlistError);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
            setError('Не удалось загрузить данные профиля');
        } finally {
            setLoading(false);
        }
    };

    const refreshStats = async () => {
        if (!token) return;

        setStatsLoading(true);
        try {
            const profileData = await userApi.getProfile(token);
            setProfile(profileData);
        } catch (error) {
            console.error('Error refreshing stats:', error);
        } finally {
            setStatsLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="loading-container" style={{ textAlign: 'center', padding: '60px 20px' }}>
                <div className="spinner" style={{
                    width: '50px',
                    height: '50px',
                    margin: '0 auto 20px',
                    border: '5px solid rgba(255, 255, 255, 0.3)',
                    borderTopColor: 'var(--accent)'
                }}></div>
                <p style={{ color: 'var(--gray)' }}>Загрузка профиля...</p>
            </div>
        );
    }

    if (!profile || !token) {
        return (
            <div className="empty-state" style={{ padding: '80px 20px' }}>
                <i className="fas fa-user-slash" style={{ fontSize: '48px', marginBottom: '16px' }}></i>
                <h3>Требуется авторизация</h3>
                <p>Пожалуйста, войдите в систему чтобы просмотреть профиль</p>
                <button className="btn" onClick={() => window.dispatchEvent(new CustomEvent('showLoginModal'))} style={{ marginTop: '15px' }}>
                    <i className="fas fa-sign-in-alt"></i> Войти
                </button>
            </div>
        );
    }

    const formatDate = (dateString) => {
        if (!dateString) return 'Не указана';
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const handleExportData = () => {
        const data = {
            profile,
            movies: userMovies,
            watchlist: userWatchlist,
            exportDate: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CineDairy-${profile.username}-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);

        // Показываем уведомление
        window.dispatchEvent(new CustomEvent('showNotification', {
            detail: { message: 'Данные успешно экспортированы!', type: 'success' }
        }));
    };

    return (
        <div className="profile-page">
            {error && (
                <div style={{
                    background: 'rgba(231, 76, 60, 0.1)',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '20px',
                    border: '1px solid rgba(231, 76, 60, 0.3)'
                }}>
                    <p style={{ color: '#ff6b6b', margin: 0 }}>
                        <i className="fas fa-exclamation-circle" style={{ marginRight: '8px' }}></i>
                        {error}
                    </p>
                </div>
            )}

            <div className="profile-header" style={{
                background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)',
                borderRadius: '15px',
                padding: '40px',
                color: 'white',
                marginBottom: '30px',
                position: 'relative',
                overflow: 'hidden'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '30px', flexWrap: 'wrap' }}>
                    <div className="profile-avatar" style={{
                        width: '120px',
                        height: '120px',
                        borderRadius: '50%',
                        background: 'rgba(255, 255, 255, 0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '60px',
                        flexShrink: 0
                    }}>
                        <i className="fas fa-user-circle"></i>
                    </div>
                    <div style={{ flex: 1, minWidth: '300px' }}>
                        <h1 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>{profile.username}</h1>
                        <p style={{ opacity: 0.9, marginBottom: '20px' }}>
                            <i className="fas fa-calendar-alt" style={{ marginRight: '8px' }}></i>
                            Участник с {formatDate(profile.joinedDate)}
                        </p>
                        <div style={{ display: 'flex', gap: '30px', flexWrap: 'wrap' }}>
                            <div className="stat">
                                <div className="stat-value" style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                                    {profile.movieCount || 0}
                                </div>
                                <div className="stat-label">Фильмов</div>
                            </div>
                            <div className="stat">
                                <div className="stat-value" style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                                    {profile.watchlistCount || 0}
                                </div>
                                <div className="stat-label">В списке</div>
                            </div>
                            <div className="stat">
                                <div className="stat-value" style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                                    {profile.averageRating ? profile.averageRating.toFixed(1) : '0.0'}
                                </div>
                                <div className="stat-label">Средняя оценка</div>
                            </div>
                        </div>
                    </div>
                </div>

                <button
                    onClick={refreshStats}
                    disabled={statsLoading}
                    style={{
                        position: 'absolute',
                        top: '20px',
                        right: '20px',
                        background: 'rgba(255, 255, 255, 0.2)',
                        border: 'none',
                        color: 'white',
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '18px',
                        transition: 'var(--transition)'
                    }}
                >
                    {statsLoading ? (
                        <div className="spinner" style={{ width: '20px', height: '20px' }}></div>
                    ) : (
                        <i className="fas fa-sync-alt"></i>
                    )}
                </button>
            </div>

            <div className="profile-tabs" style={{
                display: 'flex',
                gap: '10px',
                marginBottom: '30px',
                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                paddingBottom: '10px',
                flexWrap: 'wrap'
            }}>
                <button
                    className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
                    onClick={() => setActiveTab('overview')}
                    style={{
                        padding: '10px 20px',
                        background: activeTab === 'overview' ? 'var(--primary)' : 'transparent',
                        border: 'none',
                        color: 'white',
                        borderRadius: '5px',
                        cursor: 'pointer',
                        transition: 'var(--transition)'
                    }}
                >
                    Обзор
                </button>
                <button
                    className={`tab-btn ${activeTab === 'movies' ? 'active' : ''}`}
                    onClick={() => setActiveTab('movies')}
                    style={{
                        padding: '10px 20px',
                        background: activeTab === 'movies' ? 'var(--primary)' : 'transparent',
                        border: 'none',
                        color: 'white',
                        borderRadius: '5px',
                        cursor: 'pointer',
                        transition: 'var(--transition)'
                    }}
                >
                    Мои фильмы ({userMovies.length})
                </button>
                <button
                    className={`tab-btn ${activeTab === 'watchlist' ? 'active' : ''}`}
                    onClick={() => setActiveTab('watchlist')}
                    style={{
                        padding: '10px 20px',
                        background: activeTab === 'watchlist' ? 'var(--primary)' : 'transparent',
                        border: 'none',
                        color: 'white',
                        borderRadius: '5px',
                        cursor: 'pointer',
                        transition: 'var(--transition)'
                    }}
                >
                    Список ожидания ({userWatchlist.length})
                </button>
                <button
                    className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
                    onClick={() => setActiveTab('settings')}
                    style={{
                        padding: '10px 20px',
                        background: activeTab === 'settings' ? 'var(--primary)' : 'transparent',
                        border: 'none',
                        color: 'white',
                        borderRadius: '5px',
                        cursor: 'pointer',
                        transition: 'var(--transition)'
                    }}
                >
                    Настройки
                </button>
            </div>

            {activeTab === 'overview' && (
                <div className="overview-tab">
                    <h2 style={{ marginBottom: '20px' }}>Ваша активность</h2>
                    <div className="stats-grid" style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                        gap: '20px'
                    }}>
                        <div className="stat-card" style={{
                            background: 'var(--card-bg)',
                            padding: '25px',
                            borderRadius: '10px',
                            textAlign: 'center',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(255, 255, 255, 0.1)'
                        }}>
                            <div className="stat-value" style={{ fontSize: '2.5rem', color: 'var(--accent)' }}>
                                {profile.movieCount || 0}
                            </div>
                            <div className="stat-label">Всего просмотрено</div>
                        </div>
                        <div className="stat-card" style={{
                            background: 'var(--card-bg)',
                            padding: '25px',
                            borderRadius: '10px',
                            textAlign: 'center',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(255, 255, 255, 0.1)'
                        }}>
                            <div className="stat-value" style={{ fontSize: '2.5rem', color: 'var(--accent)' }}>
                                {profile.averageRating ? profile.averageRating.toFixed(1) : '0.0'}
                            </div>
                            <div className="stat-label">Средняя оценка</div>
                        </div>
                        <div className="stat-card" style={{
                            background: 'var(--card-bg)',
                            padding: '25px',
                            borderRadius: '10px',
                            textAlign: 'center',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(255, 255, 255, 0.1)'
                        }}>
                            <div className="stat-value" style={{ fontSize: '2.5rem', color: 'var(--accent)' }}>
                                {profile.watchlistCount || 0}
                            </div>
                            <div className="stat-label">В списке ожидания</div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'movies' && (
                <div className="movies-tab">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                        <h2>Мои фильмы</h2>
                        <button
                            className="btn btn-outline"
                            onClick={fetchUserData}
                            style={{ padding: '8px 16px', fontSize: '14px' }}
                        >
                            <i className="fas fa-sync-alt"></i> Обновить
                        </button>
                    </div>

                    {userMovies.length === 0 ? (
                        <div className="empty-state" style={{ textAlign: 'center', padding: '40px' }}>
                            <i className="fas fa-film" style={{ fontSize: '48px', marginBottom: '16px' }}></i>
                            <h3>Пока нет фильмов</h3>
                            <p>Добавьте первый фильм, чтобы он появился здесь</p>
                            <button className="btn" style={{ marginTop: '16px' }} onClick={() => window.location.href = '#add'}>
                                <i className="fas fa-plus"></i> Добавить фильм
                            </button>
                        </div>
                    ) : (
                        <div className="movies-grid">
                            {userMovies.slice(0, 12).map(movie => (
                                <div key={movie.id} className="movie-card" style={{
                                    background: 'var(--card-bg)',
                                    borderRadius: '10px',
                                    overflow: 'hidden',
                                    cursor: 'pointer',
                                    transition: 'var(--transition)'
                                }}>
                                    <img
                                        src={movie.posterUrl || 'https://via.placeholder.com/300x400/1a1a2e/6a11cb?text=No+Image'}
                                        alt={movie.title}
                                        style={{ width: '100%', height: '200px', objectFit: 'cover' }}
                                    />
                                    <div style={{ padding: '15px' }}>
                                        <h4 style={{ marginBottom: '8px', fontSize: '16px' }}>{movie.title}</h4>
                                        <p style={{ fontSize: '14px', color: 'var(--gray)', marginBottom: '8px' }}>
                                            {movie.year} • {movie.rating ? `${movie.rating}/10` : 'Без оценки'}
                                        </p>
                                        {movie.comment && (
                                            <p style={{
                                                fontSize: '13px',
                                                fontStyle: 'italic',
                                                color: 'rgba(255, 255, 255, 0.7)',
                                                marginBottom: '8px'
                                            }}>
                                                "{movie.comment.substring(0, 80)}{movie.comment.length > 80 ? '...' : ''}"
                                            </p>
                                        )}
                                        <div style={{
                                            fontSize: '12px',
                                            color: 'rgba(255, 255, 255, 0.5)',
                                            marginTop: '8px'
                                        }}>
                                            Добавлено: {formatDate(movie.createdAt)}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'watchlist' && (
                <div className="watchlist-tab">
                    <h2 style={{ marginBottom: '20px' }}>Список ожидания</h2>
                    {userWatchlist.length === 0 ? (
                        <div className="empty-state" style={{ textAlign: 'center', padding: '40px' }}>
                            <i className="fas fa-bookmark" style={{ fontSize: '48px', marginBottom: '16px' }}></i>
                            <h3>Список ожидания пуст</h3>
                            <p>Добавьте фильмы, которые хотите посмотреть в будущем</p>
                        </div>
                    ) : (
                        <div style={{ display: 'grid', gap: '12px' }}>
                            {userWatchlist.map(item => (
                                <div key={item.id} style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '15px',
                                    padding: '15px',
                                    background: 'var(--card-bg)',
                                    borderRadius: '10px',
                                    backdropFilter: 'blur(10px)',
                                    border: '1px solid rgba(255, 255, 255, 0.1)'
                                }}>
                                    <img
                                        src={item.posterUrl || 'https://via.placeholder.com/60x90/1a1a2e/6a11cb?text=No+Image'}
                                        alt={item.title}
                                        style={{ width: '60px', height: '90px', objectFit: 'cover', borderRadius: '5px' }}
                                    />
                                    <div style={{ flex: 1 }}>
                                        <div style={{ fontWeight: '600', marginBottom: '5px' }}>{item.title}</div>
                                        <div style={{ fontSize: '14px', color: 'var(--gray)' }}>
                                            {item.year} • {item.type} • {item.genre}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'settings' && (
                <div className="settings-tab">
                    <h2 style={{ marginBottom: '20px' }}>Настройки профиля</h2>
                    <div className="settings-card" style={{
                        background: 'var(--card-bg)',
                        padding: '30px',
                        borderRadius: '10px',
                        maxWidth: '500px',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255, 255, 255, 0.1)'
                    }}>
                        <div style={{ marginBottom: '20px' }}>
                            <h4 style={{ marginBottom: '10px', color: 'var(--accent)' }}>Информация об аккаунте</h4>
                            <p><strong>Имя пользователя:</strong> {profile.username}</p>
                            {profile.email && <p><strong>Email:</strong> {profile.email}</p>}
                            <p><strong>Дата регистрации:</strong> {formatDate(profile.joinedDate)}</p>
                        </div>

                        <div style={{ marginBottom: '20px' }}>
                            <h4 style={{ marginBottom: '10px', color: 'var(--accent)' }}>Экспорт данных</h4>
                            <p style={{ fontSize: '14px', marginBottom: '15px', color: 'rgba(255, 255, 255, 0.7)' }}>
                                Вы можете экспортировать все свои данные в формате JSON для резервного копирования.
                            </p>
                            <button
                                className="btn btn-outline"
                                onClick={handleExportData}
                                style={{ padding: '10px 20px', fontSize: '14px' }}
                            >
                                <i className="fas fa-download"></i> Экспорт данных
                            </button>
                        </div>

                        <div>
                            <h4 style={{ marginBottom: '10px', color: 'var(--accent)' }}>Опасная зона</h4>
                            <p style={{ fontSize: '14px', marginBottom: '15px', color: 'rgba(255, 255, 255, 0.7)' }}>
                                Выйти из аккаунта. Вы сможете войти снова с тем же именем пользователя и паролем.
                            </p>
                            <button
                                className="btn btn-danger"
                                onClick={onLogout}
                                style={{ padding: '10px 20px', fontSize: '14px' }}
                            >
                                <i className="fas fa-sign-out-alt"></i> Выйти
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}