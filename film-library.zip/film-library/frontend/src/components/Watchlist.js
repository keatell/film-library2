import React, { useState, useEffect } from 'react';

export default function Watchlist({ items, onDelete, onMoveToWatched, token }) {
    const [localItems, setLocalItems] = useState(items);
    const [loading, setLoading] = useState(false);

    // Синхронизируем локальные элементы с props
    useEffect(() => {
        setLocalItems(items);
    }, [items]);

    const handleDelete = async (id) => {
        setLoading(true);
        try {
            await onDelete(id);
        } finally {
            setLoading(false);
        }
    };

    const handleMoveToWatched = async (item) => {
        setLoading(true);
        try {
            await onMoveToWatched(item);
        } finally {
            setLoading(false);
        }
    };

    if (!localItems || localItems.length === 0) {
        return (
            <div className="empty-state">
                <i className="fas fa-bookmark" style={{ fontSize: '48px', marginBottom: '16px' }}></i>
                <h3>Список "Хочу посмотреть" пуст</h3>
                <p>Добавьте фильмы или сериалы, которые хотите посмотреть в будущем</p>
                {!token && (
                    <p style={{ color: 'var(--gray)', fontSize: '14px', marginTop: '10px' }}>
                        Войдите, чтобы синхронизировать список между устройствами
                    </p>
                )}
            </div>
        );
    }

    return (
        <div>
            <h1 className="page-title">Хочу посмотреть</h1>

            {!token && (
                <div className="info-box" style={{
                    background: 'rgba(255, 209, 102, 0.1)',
                    padding: '15px',
                    borderRadius: '10px',
                    marginBottom: '25px',
                    border: '1px solid rgba(255, 209, 102, 0.3)'
                }}>
                    <i className="fas fa-info-circle" style={{ color: 'var(--accent)', marginRight: '8px' }}></i>
                    <span>Работаете с локальным списком. Войдите, чтобы синхронизировать данные.</span>
                </div>
            )}

            {loading && (
                <div style={{ textAlign: 'center', margin: '20px 0' }}>
                    <div className="spinner" style={{ width: '30px', height: '30px', margin: '0 auto' }}></div>
                    <p style={{ color: 'var(--gray)', fontSize: '14px' }}>Обработка...</p>
                </div>
            )}

            <div style={{ display: 'grid', gap: '12px' }}>
                {localItems.map(item => (
                    <div className="watchlist-item" key={item.id}>
                        <img
                            src={item.posterUrl || item.poster || 'https://via.placeholder.com/60x90/1a1a2e/6a11cb?text=No+Image'}
                            className="watchlist-poster"
                            alt={item.title}
                            style={{
                                width: '60px',
                                height: '90px',
                                objectFit: 'cover',
                                borderRadius: '5px'
                            }}
                        />
                        <div className="watchlist-info" style={{ flex: 1 }}>
                            <div className="watchlist-title" style={{
                                fontWeight: '600',
                                marginBottom: '5px',
                                fontSize: '16px'
                            }}>
                                {item.title}
                            </div>
                            <div className="watchlist-meta" style={{
                                fontSize: '0.9rem',
                                color: 'var(--gray)',
                                display: 'flex',
                                flexWrap: 'wrap',
                                gap: '8px'
                            }}>
                                <span>{item.year || 'Год не указан'}</span>
                                <span>•</span>
                                <span>{item.type || 'Фильм'}</span>
                                {item.genre && <span>• {item.genre.split(',').slice(0, 2).join(', ')}</span>}
                            </div>
                            {item.addedDate && (
                                <div style={{
                                    fontSize: '12px',
                                    color: 'rgba(255, 255, 255, 0.5)',
                                    marginTop: '5px'
                                }}>
                                    Добавлено: {new Date(item.addedDate).toLocaleDateString('ru-RU')}
                                </div>
                            )}
                        </div>
                        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                            <button
                                className="btn btn-accent"
                                onClick={() => handleMoveToWatched(item)}
                                disabled={loading}
                                style={{
                                    padding: '8px 16px',
                                    fontSize: '14px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}
                            >
                                <i className="fas fa-eye"></i>
                                Посмотрел
                            </button>
                            <button
                                className="btn btn-danger"
                                onClick={() => handleDelete(item.id)}
                                disabled={loading}
                                style={{
                                    padding: '8px 12px',
                                    fontSize: '14px'
                                }}
                            >
                                <i className="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            <div style={{
                marginTop: '30px',
                padding: '15px',
                background: 'rgba(255, 255, 255, 0.05)',
                borderRadius: '10px',
                textAlign: 'center'
            }}>
                <p style={{ color: 'var(--gray)', fontSize: '14px', margin: 0 }}>
                    Всего элементов: <strong>{localItems.length}</strong>
                </p>
            </div>
        </div>
    );
}