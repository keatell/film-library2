import React from 'react';

export default function Notification({ message, type = 'info' }) {
  const bgColors = {
    success: 'linear-gradient(135deg, #2ecc71, #27ae60)',
    error: 'linear-gradient(135deg, #e74c3c, #c0392b)',
    info: 'linear-gradient(135deg, #3498db, #2980b9)',
    warning: 'linear-gradient(135deg, #f39c12, #d35400)'
  };

  const icons = {
    success: 'fas fa-check-circle',
    error: 'fas fa-exclamation-circle',
    info: 'fas fa-info-circle',
    warning: 'fas fa-exclamation-triangle'
  };

  return (
      <div className="notification" style={{
        position: 'fixed',
        bottom: '30px',
        right: '30px',
        background: bgColors[type],
        color: 'white',
        padding: '16px 24px',
        borderRadius: '12px',
        boxShadow: '0 8px 25px rgba(0, 0, 0, 0.3)',
        zIndex: 2000,
        animation: 'slideIn 0.3s ease',
        maxWidth: '400px',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <i className={icons[type]} style={{ fontSize: '20px' }}></i>
        <span style={{ flex: 1 }}>{message}</span>
      </div>
  );
}