import React, { useEffect, useState, useCallback } from 'react';
import Header from './components/Header';
import MovieList from './components/MovieList';
import MovieDetail from './components/MovieDetail';
import AddMovieForm from './components/AddMovieForm';
import Watchlist from './components/Watchlist';
import Stats from './components/Stats';
import Notification from './components/Notification';
import Profile from './components/Profile';

const STORAGE_MOVIES = 'movies';
const STORAGE_WATCHLIST = 'watchlist';

function decodeJwt(token) {
  try {
    const payload = token.split('.')[1];
    const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
    try {
      return JSON.parse(decodeURIComponent(escape(json)));
    } catch (e) {
      return JSON.parse(json);
    }
  } catch (e) {
    return null;
  }
}

export default function App() {
  const [page, setPage] = useState('home');
  const [selected, setSelected] = useState(null);
  const [movies, setMovies] = useState([]);
  const [watchlist, setWatchlist] = useState([]);
  const [notification, setNotification] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(false);

  // Функция загрузки данных пользователя
  const fetchUserData = useCallback(async () => {
    if (!token) return;

    setLoadingData(true);
    try {
      // Загружаем фильмы пользователя
      const moviesResponse = await fetch('http://localhost:8080/api/movies/my', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (moviesResponse.ok) {
        const moviesData = await moviesResponse.json();
        setMovies(moviesData.content || moviesData || []);
      } else {
        console.warn('Failed to fetch movies:', moviesResponse.status);
      }

      // Загружаем список ожидания
      const watchlistResponse = await fetch('http://localhost:8080/api/watchlist', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (watchlistResponse.ok) {
        const watchlistData = await watchlistResponse.json();
        setWatchlist(watchlistData.content || watchlistData || []);
      } else {
        console.warn('Failed to fetch watchlist:', watchlistResponse.status);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoadingData(false);
    }
  }, [token]);

  const fetchUserProfile = useCallback(async (token) => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:8080/api/user/profile', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setUser(data);
        console.log('User profile loaded:', data);
      } else {
        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem('token');
          setToken(null);
          setUser(null);
          setPage('home');
          console.warn('Token invalid - cleared');
        } else {
          console.warn(`Profile endpoint returned ${response.status}`);
          const decoded = decodeJwt(token);
          if (decoded) {
            const fallbackUser = {
              id: decoded.sub || decoded.id,
              username: decoded.username || decoded.sub || 'User',
            };
            setUser(fallbackUser);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching user profile:', error);
      const decoded = decodeJwt(token);
      if (decoded) {
        const fallbackUser = {
          id: decoded.sub || decoded.id,
          username: decoded.username || decoded.sub || 'User',
        };
        setUser(fallbackUser);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  // Проверяем токен и загружаем данные при загрузке
  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
      fetchUserProfile(storedToken);
    } else {
      // Загружаем локальные данные для незалогиненных пользователей
      const localMovies = JSON.parse(localStorage.getItem(STORAGE_MOVIES)) || [];
      const localWatchlist = JSON.parse(localStorage.getItem(STORAGE_WATCHLIST)) || [];
      setMovies(localMovies);
      setWatchlist(localWatchlist);
    }
  }, [fetchUserProfile]);

  // Загружаем данные пользователя при изменении токена
  useEffect(() => {
    if (token) {
      fetchUserData();
    }
  }, [token, fetchUserData]);

  // Сохраняем локальные данные только для незалогиненных пользователей
  useEffect(() => {
    if (!token) {
      localStorage.setItem(STORAGE_MOVIES, JSON.stringify(movies));
    }
  }, [movies, token]);

  useEffect(() => {
    if (!token) {
      localStorage.setItem(STORAGE_WATCHLIST, JSON.stringify(watchlist));
    }
  }, [watchlist, token]);

  function showNotification(message, type = 'info') {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  }

  function handleLogin(token) {
    console.log('Login successful, token:', token);
    localStorage.setItem('token', token);
    setToken(token);
    showNotification('Вход выполнен успешно!', 'success');
  }

  function handleLogout() {
    console.log('Logging out');
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);

    // Очищаем серверные данные и загружаем локальные
    setMovies([]);
    setWatchlist([]);
    const localMovies = JSON.parse(localStorage.getItem(STORAGE_MOVIES)) || [];
    const localWatchlist = JSON.parse(localStorage.getItem(STORAGE_WATCHLIST)) || [];
    setMovies(localMovies);
    setWatchlist(localWatchlist);

    setPage('home');
    showNotification('Вы вышли из аккаунта', 'info');
  }

  async function addMovie(movie) {
    if (token) {
      // Отправляем на сервер
      try {
        const response = await fetch('http://localhost:8080/api/movies', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            title: movie.title,
            description: movie.description || '',
            year: movie.year ? parseInt(movie.year) : null,
            rating: movie.rating ? parseFloat(movie.rating) : null,
            comment: movie.comment || '',
            posterUrl: movie.poster || movie.posterUrl || '',
            genres: movie.genre ? new Set(movie.genre.split(',').map(g => g.trim())) : new Set(),
            type: movie.type || 'FILM'
          })
        });

        if (response.ok) {
          const saved = await response.json();
          setMovies(prev => [saved, ...prev]);
          showNotification('Фильм успешно добавлен в ваш дневник!', 'success');
        } else {
          showNotification('Ошибка при сохранении фильма', 'error');
        }
      } catch (error) {
        console.error('Error posting movie:', error);
        showNotification('Нет связи с сервером', 'error');
      }
    } else {
      // Локальное сохранение для незалогиненных
      const localMovie = {
        id: Date.now(),
        ...movie,
        rating: Number(movie.rating) || 0,
        dateAdded: new Date().toISOString()
      };
      setMovies(prev => [localMovie, ...prev]);
      showNotification('Фильм добавлен локально (войдите, чтобы синхронизировать)', 'info');
    }
  }

  // Функция updateMovie объявлена, но не используется - можно удалить или закомментировать
  /*
  async function updateMovie(movie) {
    if (token) {
      try {
        const response = await fetch(`http://localhost:8080/api/movies/${movie.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(movie)
        });

        if (response.ok) {
          const updated = await response.json();
          setMovies(prev => prev.map(m => m.id === updated.id ? updated : m));
          showNotification('Фильм обновлён', 'success');
        }
      } catch (error) {
        console.error('Error updating movie:', error);
        showNotification('Ошибка обновления фильма', 'error');
      }
    } else {
      // Локальное обновление
      setMovies(prev => prev.map(m => m.id === movie.id ? movie : m));
      showNotification('Фильм обновлён локально', 'info');
    }
  }
  */

  async function deleteMovie(id) {
    if (token) {
      // Удаляем на сервере
      try {
        const response = await fetch(`http://localhost:8080/api/movies/${id}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (response.ok) {
          setMovies(prev => prev.filter(m => m.id !== id));
          showNotification('Фильм удалён', 'info');
        } else {
          showNotification('Ошибка удаления фильма', 'error');
        }
      } catch (error) {
        console.error('Error deleting movie:', error);
        showNotification('Не удалось связаться с сервером', 'error');
      }
    } else {
      // Локальное удаление
      setMovies(prev => prev.filter(m => m.id !== id));
      showNotification('Фильм удалён (локально)', 'info');
    }
  }

  async function addToWatchlist(item) {
    if (token) {
      // Сохраняем на сервере
      try {
        const response = await fetch('http://localhost:8080/api/watchlist', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            title: item.title,
            type: item.type || 'FILM',
            genre: item.genre || '',
            year: item.year ? parseInt(item.year) : null,
            posterUrl: item.poster || ''
          })
        });

        if (response.ok) {
          const saved = await response.json();
          setWatchlist(prev => [saved, ...prev]);
          showNotification('Добавлено в "Хочу посмотреть"', 'success');
        } else {
          showNotification('Ошибка добавления в список', 'error');
        }
      } catch (error) {
        console.error('Error adding to watchlist:', error);
        showNotification('Ошибка соединения с сервером', 'error');
      }
    } else {
      // Локальное сохранение
      const localItem = {
        id: Date.now(),
        ...item,
        dateAdded: new Date().toISOString()
      };
      setWatchlist(prev => [localItem, ...prev]);
      showNotification('Добавлено локально (войдите, чтобы синхронизировать)', 'info');
    }
  }

  async function moveToWatched(item) {
    if (token) {
      try {
        // Добавляем в просмотренные
        const movieResponse = await fetch('http://localhost:8080/api/movies', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            title: item.title,
            type: item.type || 'FILM',
            year: item.year ? parseInt(item.year) : null,
            rating: 0,
            comment: 'Перемещено из списка "Хочу посмотреть"',
            posterUrl: item.posterUrl || item.poster || '',
            genres: item.genre ? new Set(item.genre.split(',').map(g => g.trim())) : new Set()
          })
        });

        if (movieResponse.ok) {
          const newMovie = await movieResponse.json();
          setMovies(prev => [newMovie, ...prev]);

          // Удаляем из списка ожидания
          const deleteResponse = await fetch(`http://localhost:8080/api/watchlist/${item.id}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });

          if (deleteResponse.ok) {
            setWatchlist(prev => prev.filter(w => w.id !== item.id));
            showNotification('Перемещено в просмотренные', 'success');
          }
        }
      } catch (error) {
        console.error('Error moving to watched:', error);
        showNotification('Ошибка перемещения', 'error');
      }
    } else {
      // Локальная операция
      setWatchlist(prev => prev.filter(w => w.id !== item.id));
      const newMovie = {
        id: Date.now(),
        title: item.title,
        type: item.type || 'FILM',
        genre: item.genre || '',
        year: item.year,
        dateWatched: new Date().toISOString().split('T')[0],
        rating: 0,
        comment: 'Перемещено из списка "Хочу посмотреть"',
        poster: item.poster || item.posterUrl || '',
        dateAdded: new Date().toISOString()
      };
      setMovies(prev => [newMovie, ...prev]);
      showNotification('Перемещено в просмотренные (локально)', 'info');
    }
  }

  async function deleteWatchlistItem(id) {
    if (token) {
      try {
        const response = await fetch(`http://localhost:8080/api/watchlist/${id}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (response.ok) {
          setWatchlist(prev => prev.filter(i => i.id !== id));
          showNotification('Удалено из списка "Хочу посмотреть"', 'info');
        } else {
          showNotification('Ошибка удаления из списка', 'error');
        }
      } catch (error) {
        console.error('Error deleting watchlist item:', error);
        showNotification('Ошибка соединения с сервером', 'error');
      }
    } else {
      // Локальное удаление
      setWatchlist(prev => prev.filter(i => i.id !== id));
      showNotification('Удалено локально', 'info');
    }
  }

  function exportData() {
    const data = { movies, watchlist, exportDate: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CineDairy-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showNotification('Данные успешно экспортированы!', 'success');
  }

  async function resetAllData() {
    if (window.confirm('Вы уверены, что хотите удалить все данные? Это действие нельзя отменить.')) {
      if (token) {
        try {
          // Удаляем все фильмы пользователя
          const moviesResponse = await fetch('http://localhost:8080/api/movies/my', {
            headers: { 'Authorization': `Bearer ${token}` }
          });

          if (moviesResponse.ok) {
            const moviesData = await moviesResponse.json();
            const moviesList = moviesData.content || moviesData || [];

            // Удаляем каждый фильм
            for (const movie of moviesList) {
              await fetch(`http://localhost:8080/api/movies/${movie.id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
              });
            }
          }

          // Удаляем весь список ожидания
          const watchlistResponse = await fetch('http://localhost:8080/api/watchlist', {
            headers: { 'Authorization': `Bearer ${token}` }
          });

          if (watchlistResponse.ok) {
            const watchlistData = await watchlistResponse.json();
            const watchlistList = watchlistData.content || watchlistData || [];

            for (const item of watchlistList) {
              await fetch(`http://localhost:8080/api/watchlist/${item.id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
              });
            }
          }

          setMovies([]);
          setWatchlist([]);
          showNotification('Все данные были сброшены', 'info');
        } catch (error) {
          console.error('Error resetting data:', error);
          showNotification('Ошибка сброса данных', 'error');
        }
      } else {
        // Локальный сброс
        setMovies([]);
        setWatchlist([]);
        showNotification('Все локальные данные сброшены', 'info');
      }
      setPage('home');
    }
  }

  if (loading) {
    return (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, var(--darker), var(--dark))',
          color: 'var(--light)'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div className="spinner" style={{
              width: '50px',
              height: '50px',
              margin: '0 auto 20px',
              border: '5px solid rgba(255, 255, 255, 0.3)',
              borderTopColor: 'var(--accent)'
            }}></div>
            <p>Загрузка профиля...</p>
          </div>
        </div>
    );
  }

  console.log('App state - Token:', token, 'User:', user);

  return (
      <div className="container-root">
        <Header
            onNavigate={setPage}
            currentPage={page}
            onExport={exportData}
            user={user}
            onLogout={handleLogout}
            onLogin={handleLogin}
        />

        <div className="main-container">
          <main style={{ padding: '24px 0' }}>
            {page === 'home' && (
                <>
                  <section className="hero">
                    <h1>Ваш личный кино‑дневник</h1>
                    <p>Отслеживайте всё, что вы посмотрели, делитесь впечатлениями и открывайте для себя новые фильмы и сериалы</p>
                    {user ? (
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap' }}>
                          <button className="btn" onClick={() => setPage('add')}>
                            <i className="fas fa-plus"></i> Добавить фильм
                          </button>
                          <button className="btn btn-accent" onClick={() => setPage('profile')}>
                            <i className="fas fa-user"></i> Мой профиль
                          </button>
                          <button className="btn btn-outline" onClick={() => setPage('stats')}>
                            <i className="fas fa-chart-bar"></i> Статистика
                          </button>
                        </div>
                    ) : (
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                          <button className="btn" onClick={() => setPage('add')}>
                            <i className="fas fa-plus"></i> Начать без входа
                          </button>
                          <button className="btn btn-accent" onClick={() => {
                            // Показываем модалку логина через window событие
                            window.dispatchEvent(new CustomEvent('showLoginModal'));
                          }}>
                            <i className="fas fa-user"></i> Войти и начать
                          </button>
                        </div>
                    )}
                  </section>

                  {loadingData ? (
                      <div style={{ textAlign: 'center', padding: '40px' }}>
                        <div className="spinner" style={{ width: '40px', height: '40px', margin: '0 auto 20px' }}></div>
                        <p>Загрузка данных...</p>
                      </div>
                  ) : (
                      <>
                        <h2 className="page-title">Недавно добавленные</h2>
                        <div id="recent-movies-list" className="movies-grid">
                          {movies.slice(0, 6).length === 0 ? (
                              <div className="empty-state">
                                <i className="fas fa-film"></i>
                                <h3>Пока нет добавленных фильмов</h3>
                                <p>Начните добавлять фильмы и сериалы, чтобы они появились здесь</p>
                              </div>
                          ) : movies.slice(0, 6).map(m => (
                              <div key={m.id} className="movie-card" onClick={() => { setSelected(m); setPage('detail'); }}>
                                <img src={m.posterUrl || m.poster || `https://via.placeholder.com/300x400/1a1a2e/6a11cb?text=No+Image`} className="movie-poster" alt={m.title} />
                                <div className="movie-info">
                                  <div className="movie-title">{m.title}</div>
                                  <div className="movie-meta">
                                    <span>{m.year || '—'}</span>
                                    <span>•</span>
                                    <span>{m.type || 'Фильм'}</span>
                                  </div>
                                  {m.comment && (
                                      <div className="movie-comment">
                                        <i className="fas fa-comment"></i> {m.comment.substring(0, 60)}...
                                      </div>
                                  )}
                                  <div className="movie-actions">
                                    <button className="btn btn-outline" onClick={(e) => {
                                      e.stopPropagation();
                                      setSelected(m);
                                      setPage('detail');
                                    }}>
                                      Подробнее
                                    </button>
                                  </div>
                                </div>
                              </div>
                          ))}
                        </div>
                      </>
                  )}
                </>
            )}

            {page === 'movies' && (
                <MovieList
                    movies={movies}
                    onOpenDetail={(m) => { setSelected(m); setPage('detail'); }}
                    onDelete={deleteMovie}
                    token={token}
                />
            )}

            {page === 'detail' && selected && (
                <MovieDetail movie={selected} onBack={() => setPage('movies')} />
            )}

            {page === 'add' && (
                <AddMovieForm
                    onAdd={addMovie}
                    onAddToWatchlist={addToWatchlist}
                    showNotification={showNotification}
                    token={token}
                />
            )}

            {page === 'watchlist' && (
                <Watchlist
                    items={watchlist}
                    onDelete={deleteWatchlistItem}
                    onMoveToWatched={moveToWatched}
                    token={token}
                />
            )}

            {page === 'stats' && (
                <Stats movies={movies} watchlist={watchlist} onReset={resetAllData} token={token} />
            )}

            {page === 'profile' && user && (
                <Profile user={user} token={token} onLogout={handleLogout} />
            )}

            {page === 'profile' && !user && (
                <div className="empty-state">
                  <i className="fas fa-user-slash"></i>
                  <h3>Требуется авторизация</h3>
                  <p>Пожалуйста, войдите в систему чтобы просмотреть профиль</p>
                  <button className="btn" onClick={() => window.dispatchEvent(new CustomEvent('showLoginModal'))} style={{ marginTop: '15px' }}>
                    Войти
                  </button>
                </div>
            )}
          </main>
        </div>

        <footer className="footer">
          <div className="main-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '20px' }}>
              <span>© CineDairy 2023</span>
              <div style={{ display: 'flex', gap: '20px' }}>
                <button
                    onClick={(e) => {
                      e.preventDefault();
                      showNotification('О проекте: Кино-дневник для отслеживания просмотренных фильмов');
                    }}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--gray)',
                      cursor: 'pointer',
                      textDecoration: 'underline'
                    }}
                >
                  О проекте
                </button>
                <button
                    onClick={(e) => {
                      e.preventDefault();
                      showNotification('Контакты: поддержка@cinedairy.ru');
                    }}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--gray)',
                      cursor: 'pointer',
                      textDecoration: 'underline'
                    }}
                >
                  Контакты
                </button>
                {user && <span style={{ color: 'var(--accent)' }}>Привет, {user.username}!</span>}
              </div>
            </div>
          </div>
        </footer>

        {notification && <Notification {...notification} />}
      </div>
  );
}